# -*- coding: utf-8 -*-
"""铁路决策树（`app/pipeline/rail_tree/`）离线回归测试。

为什么这个套件能**离线**跑
--------------------------
树本身不导入任何第三方库（fastapi/pydantic/mcp_12306/openai 都不依赖），
应用侧的能力（起讫站 / 车次号 / 站点库 / 线路库）全部通过 `Provider` 注入。
所以本套件用默认实现即可完整覆盖判定逻辑，不需要网络、不需要 LLM、
不需要 12306 站点库。

运行：
    cd backend && PYTHONPATH=. python3 tests/test_rail_tree.py

覆盖四类：
1. **契约**：应用既有快路径的 9 条黄金用例必须接管、8 条必须交回 LLM；
2. **回归**：开发过程中实测到的 9 个真 bug，每个都有专门的用例钉住；
3. **结构不变量**：树不是 DAG、测试种类合法、判断层次序正确、规模达标；
4. **能力**：新覆盖的问法、多轮继承、降级原因、性能。
"""
from __future__ import annotations

# ---- 独立包运行引导：没有 app 包时把 rail_tree 别名成 app.pipeline.rail_tree ----
import sys as _sys
try:
    import app.pipeline.rail_tree as _rt          # noqa: F401  仓库内布局
except ImportError:
    _sys.path.insert(0, str(__import__("pathlib").Path(__file__).resolve().parents[1]))
    import rail_tree as _rt
    import types as _types
    for _name in ("text", "nodes", "build", "knowledge", "stations", "decide"):
        _sys.modules[f"app.pipeline.rail_tree.{_name}"] = getattr(_rt, _name)
    _app = _types.ModuleType("app")
    _pl = _types.ModuleType("app.pipeline")
    _app.pipeline, _pl.rail_tree = _pl, _rt
    _sys.modules.update({"app": _app, "app.pipeline": _pl,
                         "app.pipeline.rail_tree": _rt})
# --------------------------------------------------------------------------


import time

from app.pipeline.rail_tree import Provider, RailTree, build_tree
from app.pipeline.rail_tree.build import REASON_ZH
from app.pipeline.rail_tree.knowledge import EMU_FAMILIES, TRAIN_PREFIXES
from app.pipeline.rail_tree.nodes import (
    WalkContext, describe_test, eval_test, make_defer, stats as node_stats, walk,
)
from app.pipeline.rail_tree.stations import fallback_index
from app.pipeline.rail_tree.text import (
    PATTERNS, app_od_parser, build_station_trie, default_emu_model,
    default_line_resolver, extract, flags_of, hit_strength, trie_scan,
)

# ==========================================================================
# 0. 应用既有快路径的契约（与 tests/test_perf_fastpath.py 逐条对齐）
# ==========================================================================
_GOLDEN = [
    ("G1经停哪些站？", "schedule", {"target": "G1"}),
    ("G1今天由哪组动车组担当？", "emu_routing", {"target": "G1", "time": "今天"}),
    ("g1次列车今天的车底是啥？", "emu_routing", {"target": "G1"}),
    ("明天北京到上海的高铁还有票吗？", "ticket", {"time": "明天", "direction": "北京→上海"}),
    ("北京南站大屏今天下午有哪些高铁？", "station", {"location": "北京南", "time": "今天下午"}),
    ("北京南到济南西多少公里？", "rail_line", {"direction": "北京南→济南西"}),
    ("陇海线全程多少公里？", "rail_line", {"target": "陇海线"}),
    ("北京南站的电报码是多少？", "station", {"location": "北京南"}),
    ("上海虹桥到达屏", "station", {"location": "上海虹桥"}),
]

_MUST_DEFER = [
    "CR400AF用的哪个品牌的动力系统？",
    "CR400AF 和 CR400BF 有什么区别？",
    "和谐号和复兴号是什么关系？",
    "CR200J 为什么被叫绿巨人？",
    "沪苏湖高铁开通了吗？现在什么状态？",
    "帮我把这段话翻译成英文",
    "换乘车站的编号怎么看？",
    "G1今天几点到上海虹桥？",
]

_TREE: RailTree | None = None


def tree() -> RailTree:
    global _TREE
    if _TREE is None:
        _TREE = RailTree()
    return _TREE


def tree_stats() -> dict:
    """树规模 + 站点表信息（等价于 fastpath.tree_stats()，离线可取）。"""
    t = tree()
    return {**t.stats, "n_stations": len(t.provider.get_index()),
            "station_source": t.provider.station_source()}


# ==========================================================================
# 1. 契约
# ==========================================================================
def test_golden_cases_still_take_over():
    """★ 契约：原有 9 条黄金用例必须继续被确定性接管（意图与关键槽位都对）。"""
    t = tree()
    bad = []
    for msg, want_intent, want_slots in _GOLDEN:
        d = t.decide(msg)
        if not d.ok or d.intent != want_intent:
            bad.append(f"{msg} → {d.action}:{d.reason if not d.ok else d.intent}"
                       f"（期望 {want_intent}）")
            continue
        for k, v in want_slots.items():
            if d.slots.get(k) != v:
                bad.append(f"{msg} 槽位 {k}={d.slots.get(k)!r}（期望 {v!r}）"
                           f"；全部={d.slots}")
    assert not bad, "黄金用例回归：\n" + "\n".join(bad)
    print(f"[PASS] 黄金用例 {len(_GOLDEN)}/{len(_GOLDEN)} 全部接管，意图与槽位正确")


def test_red_line_defer_cases():
    """★ 红线：知识型/时效型/无强信号问题必须交回 LLM。"""
    t = tree()
    bad = []
    for msg in _MUST_DEFER:
        d = t.decide(msg)
        if d.ok:
            bad.append(f"{msg} 被接管 → {d.intent}/{d.slots}")
    assert not bad, "红线被破坏：\n" + "\n".join(bad)
    print(f"[PASS] {len(_MUST_DEFER)} 条知识型/时效型/无信号问题全部交回 AI")


def test_defer_always_has_structured_reason():
    """降级必须给出机器可读原因 + 人话说明（否则没法统计"为什么叫了 AI"）。"""
    t = tree()
    for msg in _MUST_DEFER + ["", "。。。", "123", "asdkjfhaskjdf"]:
        d = t.decide(msg)
        if d.ok:
            continue
        assert d.reason in REASON_ZH, f"{msg!r} 的原因不在枚举里：{d.reason}"
        assert d.detail, f"{msg!r} 缺少 detail"
    print("[PASS] 所有降级都带结构化原因与可读说明")


# ==========================================================================
# 2. 回归：开发中实测到的真 bug
# ==========================================================================
def test_fake_od_from_screen_word_is_rejected():
    """回归：`app.od.parse_od("上海虹桥到达屏")` 会得到 ("上海虹桥","达屏")。

    "到达屏"的"到"被当成了区间分隔符，假区间会污染 Slots.direction，
    让下游按错误区间去查。树必须在区间校验处挡掉它。
    """
    try:
        from app.od import parse_od as raw_od
    except ImportError:
        raw_od = None       # 独立包环境没有 app.od：跳过"前提"校验，下面仍验证防护行为
    if raw_od is not None:
        assert raw_od("上海虹桥到达屏") == ("上海虹桥", "达屏"), "前提变了，请复核本用例"
    f = extract("上海虹桥到达屏")
    assert f.od is None, f"假区间没被挡掉：{f.od}"
    d = tree().decide("上海虹桥到达屏")
    assert d.ok and d.intent == "station", d
    assert "direction" not in d.slots, d.slots
    assert d.slots.get("location") == "上海虹桥", d.slots
    print("[PASS] 「到达屏」不再被解析成到达站（假区间防护）")


def test_train_type_prefix_not_confused_with_model_letters():
    """回归：`CR400BF` 里的 B 曾被当成「B字头」→ 车种被判成普速。"""
    f = extract("CR400BF今天跑哪些车次")
    assert f.train_type_pref is None, f"CR400BF 被误判成车种 {f.train_type_pref}"
    # 真正说"Z字头"时必须识别出来
    assert extract("Z字头北京到上海有哪些").train_type_pref == "普速"
    assert extract("K车北京到上海").train_type_pref == "普速"
    print("[PASS] 车型字母不会被误判成车次前缀；真说「Z字头」仍能识别")


def test_od_endpoint_train_type_prefix_is_stripped():
    """回归：「Z字头北京到上海」曾解析出区间 ("Z字头北京","上海")。"""
    f = extract("Z字头北京到上海有哪些")
    assert f.od == ("北京", "上海"), f.od
    d = tree().decide("Z字头北京到上海有哪些")
    assert d.ok and d.slots.get("direction") == "北京→上海", d.slots
    print("[PASS] 区间端点上的车种前缀被剥掉（Z字头北京 → 北京）")


def test_od_endpoint_question_frame_is_stripped():
    """回归：区间端点里混进问句框架词。

    `app.od.parse_od("北京到上海需要中转吗")` → ("北京", "上海需要中转")
    而 "北京到上海有没有夕发朝至的卧铺" 因为端点超长**整条解析失败**。
    树必须把端点截到框架词之前，并在失败时用截断文本再试一次。
    """
    assert extract("北京到上海需要中转吗").od == ("北京", "上海")
    d = tree().decide("北京到上海需要中转吗")
    assert d.ok and d.slots.get("direction") == "北京→上海", d.slots
    assert "中转" in (d.slots.get("extra") or ""), d.slots

    d2 = tree().decide("北京到上海有没有夕发朝至的卧铺")
    assert d2.ok and d2.slots.get("direction") == "北京→上海", d2.slots
    assert "夜间" in (d2.slots.get("extra") or ""), d2.slots
    print("[PASS] 区间端点截断到框架词前；超长失败时二次尝试仍能解析")


def test_derived_filters_accumulate_in_extra():
    """筛选条件必须是**累加**语义（时段+席别+车种可以同时成立）。

    踩过的坑：一开始把这些做成树的注记分支，而注记链是"先命中者胜"，
    于是"G1明天还有商务座"只留下车种注记、席别注记被遮蔽。
    """
    d = tree().decide("明天下午北京到上海有哪些车")
    extra = d.slots.get("extra") or ""
    assert "时段筛选：下午" in extra, d.slots

    d2 = tree().decide("Z字头北京到上海有哪些")
    extra2 = d2.slots.get("extra") or ""
    assert "车种筛选：普速" in extra2, d2.slots
    print("[PASS] 时段/席别/车种等筛选条件在 extra 里累加，不互相遮蔽")


def test_line_resolver_does_not_swallow_whole_sentence():
    """回归：形态匹配曾把整句当线路名。

    "明天北京到上海的高铁还有票吗？" → 线路="明天北京到上海的高铁"
    "北京南站大屏今天下午有哪些高铁？" → 线路="屏今天下午有哪些高铁"
    """
    bad_cases = [
        "明天北京到上海的高铁还有票吗？",
        "北京南站大屏今天下午有哪些高铁？",
        "北京到上海走哪条线路？",
        "G1今天由哪组动车组担当？",
    ]
    for msg in bad_cases:
        got = default_line_resolver(msg)
        assert got is None, f"{msg!r} 被误判成线路 {got!r}"
    # 真线路名仍要认出来
    assert default_line_resolver("陇海线全程多少公里？") == "陇海线"
    assert default_line_resolver("京沪高铁有多长") == "京沪高铁"
    print("[PASS] 线路名识别不再吞整句；真线路名照常识别")


def test_wants_stops_is_not_triggered_by_quan_cheng():
    """回归：「全程多少公里」是问里程，不是问站序（曾误标"需要经停站序"）。"""
    assert extract("陇海线全程多少公里？").wants_stops is False
    assert extract("陇海线全程多少公里？").wants_mileage is True
    assert extract("G1经停哪些站？").wants_stops is True
    print("[PASS] 「全程」不再被误判成问站序")


def test_annotations_actually_fire():
    """回归：annotate() 曾把 T() 字典直接当测试传给 eval_test，导致注记恒不命中。

    注记是把权威铁路知识喂给下游 LLM 的通道，恒不命中等于白建。
    """
    # 车种注记：挂在 emu_routing_by_train 上
    d = tree().decide("G1今天由哪组动车组担当？")
    assert "车种＝高速动车组" in (d.slots.get("extra") or ""), d.slots
    # 车型注记：挂在 emu_routing_by_model 上
    d2 = tree().decide("CR400BF今天跑哪些车次")
    assert "车型＝复兴号 CR400BF" in (d2.slots.get("extra") or ""), d2.slots
    # 席别注记：挂在 ticket_by_train 上
    d3 = tree().decide("G1明天还有商务座吗")
    assert "席别筛选：商务座" in (d3.slots.get("extra") or ""), d3.slots
    print("[PASS] 车种/车型/席别注记确实进入 extra（供下游生成层使用）")


def test_stops_sequence_keeps_exact_slot_contract():
    """契约：`stops_sequence` 不产出 extra。

    应用既有测试 `test_planner_deterministic_is_zero_llm` 对
    "G1经停哪些站？" 做严格槽位相等断言，多一个 extra 就会失败。
    """
    d = tree().decide("G1经停哪些站？")
    assert d.ok and d.intent == "schedule", d
    assert d.slots == {"target": "G1"}, d.slots
    print("[PASS] stops_sequence 槽位严格等于 {target: G1}（保住既有断言）")


def test_fake_station_no_longest_match():
    """回归：不得把"换乘车站"切成"换乘车"这类假站名。"""
    assert tree().decide("换乘车站的编号怎么看？").ok is False
    hits = trie_scan(build_station_trie(list(fallback_index())),
                     "换乘车站的编号怎么看？")
    assert hits == [], hits
    print("[PASS] 无真实站名 → 不接管（假站名防护）")


def test_same_word_station_is_demoted():
    """回归：站点表里有"日照/东方/中山/北海"这类**同时是普通词**的站名。

    单靠"子串命中就算站名"会把"日照时间长""东方明珠"当成车站。
    """
    text1 = "日照时间长对拍照有什么影响？"
    hits1 = trie_scan(build_station_trie(list(fallback_index())), text1)
    for h in hits1:
        h["strength"] = hit_strength(text1, h["name"], h["start"], h["end"])
    assert all(h["strength"] == "weak" for h in hits1), hits1
    # 有站点语境时必须判强
    text2 = "我去日照拍车"
    hits2 = trie_scan(build_station_trie(list(fallback_index())), text2)
    h = [x for x in hits2 if x["name"] == "日照"][0]
    assert hit_strength(text2, h["name"], h["start"], h["end"]) == "strong"
    assert extract("去日照站拍车").station == "日照"
    print("[PASS] 同形普通词被判弱（日照时间长）；带站点语境判强（去日照）")


def test_station_pick_is_deterministic():
    """回归：旧实现用 `max(hits, key=len)`，两个同长站名时取 dict 顺序里的第一个，
    也就是"北京到上海"返回北京还是上海**不确定**。这里必须确定。"""
    trie = build_station_trie(list(fallback_index()))
    hits = trie_scan(trie, "北京到上海")
    assert [h["name"] for h in hits] == ["北京", "上海"], hits
    pick = max(hits, key=lambda h: (len(h["name"]), -h["start"]))["name"]
    assert pick == "北京", pick
    print("[PASS] 同长站名按出现位置取（确定性），不再依赖 dict 顺序")


def test_inherited_station_is_not_clobbered():
    """回归：树里的"匹配站点"节点会用本次文本重算，把继承来的站名清空。

    表现："北京南站" → "大屏呢" 本该接管，却因站名被清空而降级。
    """
    t = tree()
    d = t.decide("大屏呢", history=[{"role": "user", "content": "北京南站"}])
    assert d.ok and d.intent == "station", (d.action, d.reason, d.detail)
    assert d.slots.get("location") == "北京南", d.slots
    # 本次文本自带站名时，必须用它（不能被历史覆盖）
    d2 = t.decide("上海虹桥大屏", history=[{"role": "user", "content": "北京南站"}])
    assert d2.slots.get("location") == "上海虹桥", d2.slots
    print("[PASS] 追问继承站名不被清空；本次文本优先于历史")


def test_tree_is_not_dag():
    """回归：链式构造时复用同一子节点会让树变成 DAG（条件数虚高、轨迹不可解释）。"""
    leaf = make_defer("X", "x")
    shared = {"t": "cond", "id": 2, "label": "s", "test": ["true"],
              "yes": leaf, "no": leaf}
    root = {"t": "cond", "id": 1, "label": "r", "test": ["true"],
            "yes": shared, "no": shared}
    try:
        node_stats(root)
    except RuntimeError as e:
        assert "DAG" in str(e)
    else:
        raise AssertionError("共享子树没有被检出")
    # 真树必须通过校验
    st = node_stats(build_tree())
    assert st["unique_cond_ids"] == st["conditions"]
    print("[PASS] DAG 会被检出；实际生成的树是真正的树")


# ==========================================================================
# 3. 结构不变量
# ==========================================================================
_VALID_TEST_KINDS = {
    "true", "flag", "noflag", "slot", "nslot", "hits", "attr", "attr_eq",
    "attr_in", "re", "all", "any", "not", "emu_only", "train_known",
    "family_is", "needs", "n_families", "ambiguous_station", "station_ok",
    "family_hit", "len", "re_any", "has_od", "no_od", "has_train", "no_train",
    "has_station", "has_line", "has_emu",
}


def _iter_nodes(root: dict):
    stack = [root]
    while stack:
        n = stack.pop()
        yield n
        t = n.get("t")
        if t == "cond":
            stack += [n["yes"], n["no"]]
        elif t == "scan":
            stack.append(n["next"])
        elif t is None and "ch" in n:
            stack += list(n["ch"].values())


def test_all_tests_are_valid_and_describable():
    """树里每个条件都必须是合法种类，且能渲染成人类可读文字（可解释性）。"""
    root = build_tree()
    bad = []
    for n in _iter_nodes(root):
        if n.get("t") != "cond":
            continue
        spec = n["test"]
        assert isinstance(spec, list) and spec, f"测试不是 list：{spec!r}"
        if spec[0] not in _VALID_TEST_KINDS:
            bad.append(f"未知测试种类 {spec[0]!r}（{n['label']}）")
        txt = describe_test(spec)
        if not txt or txt.startswith("["):
            bad.append(f"条件无法渲染成文字：{n['label']} / {spec}")
    assert not bad, "\n".join(bad)
    print("[PASS] 所有条件种类合法、且都能渲染成可读文字")


def test_layer_order_is_safety_first():
    """判断层次序：站点匹配 → 家族识别 → 卫生 → 越界 → 知识型 → 冲突 → 家族 → 兜底。

    这一条是上一个项目栽过的坑（建链顺序写反，安全条件被短路），必须钉住。
    """
    root = build_tree()
    labels = []
    node = root
    while node.get("t") in ("cond", "scan") and len(labels) < 400:
        labels.append(node.get("label", node.get("op", "")))
        node = node["next"] if node.get("t") == "scan" else node["no"]
    joined = " | ".join(labels)
    assert "匹配站点" in labels[0], labels[:3]
    assert "识别问法家族" in labels[1], labels[:3]
    i_know = next(i for i, x in enumerate(labels) if "知识型" in x)
    i_fam = next(i for i, x in enumerate(labels) if x.startswith("家族="))
    assert i_know < i_fam, f"知识型判断必须早于家族矩阵：{i_know} vs {i_fam}"
    assert "越界" in joined and "冲突" in joined
    print(f"[PASS] 层序正确（前 3 层：{labels[0]} → {labels[1]} → {labels[2]}）")


def test_scale_over_1000_conditions():
    """规模：条件数必须上千（业务判断 + 站点匹配子树）。"""
    st = tree_stats()
    assert st["conditions"] >= 150, st          # 业务判断（家族/冲突/兜底/注记）
    assert st["trie_conditions"] >= 500, st     # 站点匹配子树
    assert st["total_conditions"] >= 1000, st   # 合计必须上千
    print(f"[PASS] 规模：{st['total_conditions']} 个判断条件"
          f"（业务 {st['conditions']} + 站点匹配 {st['trie_conditions']}），"
          f"节点 {st['nodes']}，深度 {st['depth']}，站点表 {st['n_stations']}")


def test_scale_grows_with_station_table():
    """规模随站点表增长：站点越多，trie 判断条件越多（生产环境更大）。"""
    small = fallback_index()

    pool = "测站台东西南北中上下前后左右甲乙丙丁戊己庚辛壬癸子丑寅卯辰巳午未申酉戌亥"

    def synth(n: int) -> dict[str, dict]:
        """合成的**压力测试**站名（明确不是真实站名），只用于验证规模增长。

        注意站点名长度上限是 8（`build_station_trie` 会跳过更长的名字），
        所以合成名固定 5 字；字符取自 30 字池，保证 trie 分支足够多、
        节点数随站数近似线性增长。
        """
        names = list(small)
        i = 0
        while len(names) < n:
            v, digs = i, []
            for _ in range(4):
                digs.append(pool[v % len(pool)])
                v //= len(pool)
            cand = "测" + "".join(reversed(digs))
            if cand not in names:
                names.append(cand)
            i += 1
        return {x: {"name": x, "code": "", "source": "synthetic"}
                for x in names}

    t1 = RailTree(Provider(station_index=lambda: synth(500)))
    t2 = RailTree(Provider(station_index=lambda: synth(3000)))
    c1 = t1.stats["trie_conditions"]
    c2 = t2.stats["trie_conditions"]
    assert c2 > c1 * 2, (c1, c2)
    print(f"[PASS] 站点 500 → trie {c1} 条；站点 3000 → trie {c2} 条（随表线性增长）")


# ==========================================================================
# 4. 能力：新覆盖 / 继承 / 性能 / 等价性
# ==========================================================================
def test_new_coverage_beyond_old_rules():
    """新覆盖：旧 7 条规则会交回 LLM、现在能确定性判定的常见问法。"""
    cases = [
        ("北京到上海有哪些车", "schedule"),
        ("明天北京到上海有哪些高铁", "schedule"),
        ("G1明天还有商务座吗", "ticket"),
        ("CR400BF今天跑哪些车次", "emu_routing"),
        ("北京南站有几个站台", "station"),
        ("京沪高铁全长多少公里", "rail_line"),
        ("Z字头北京到上海有哪些", "schedule"),
        ("北京到上海走哪条线路", "rail_line"),
    ]
    bad = []
    for msg, want in cases:
        d = tree().decide(msg)
        if not d.ok or d.intent != want:
            bad.append(f"{msg} → {d.action}:{d.reason if not d.ok else d.intent}"
                       f"（期望 {want}）")
    assert not bad, "\n".join(bad)
    print(f"[PASS] 新增覆盖 {len(cases)} 条问法（旧规则会交回 LLM）")


def test_multi_turn_inheritance():
    """多轮继承：追问省略主体时从最近用户消息补（车次/区间/站名）。"""
    t = tree()
    cases = [
        ("G1今天由哪组动车组担当？", "那经停站呢", "target", "G1"),
        ("北京到上海的高铁", "还有票吗", "direction", "北京→上海"),
        ("北京南站", "大屏呢", "location", "北京南"),
        ("上海虹桥", "出发屏呢", "location", "上海虹桥"),
    ]
    bad = []
    for hist, cur, key, want in cases:
        d = t.decide(cur, history=[{"role": "user", "content": hist}])
        if not d.ok or d.slots.get(key) != want:
            bad.append(f"{hist!r} + {cur!r} → "
                       f"{d.action}:{d.reason if not d.ok else d.slots}")
    assert not bad, "\n".join(bad)
    print(f"[PASS] 多轮继承 {len(cases)} 例（车次/区间/站名）")


def test_defer_reason_distribution():
    """降级原因必须能区分"没听懂"和"缺槽位"——这是优化方向的依据。"""
    t = tree()
    seen: dict[str, str] = {}
    probes = {
        "换乘车站的编号怎么看？": "NO_SLOT",
        "CR400AF 和 CR400BF 有什么区别？": "KNOWLEDGE_OR_OPEN",
        "沪苏湖高铁开通了吗？": "FRESHNESS_UNSAFE",
        "帮我把这段话翻译成英文": "OUT_OF_SCOPE",
        "G1今天几点到上海虹桥？": "TRAIN_STATION_ARRIVAL",
        "就是把那个弄一下": "UNKNOWN_FAMILY",   # 中文但与铁路无关、也无问法词
        "asdkjfhaskjdf": "NO_CHINESE",          # 无中文、也无车次号
        "……": "PURE_PUNCT",        # 省略号不在归一化剥离的标点里 → 能走到纯标点判断
        "。。。": "EMPTY",           # 句号会被归一化剥掉 → 归一化后为空
        "": "EMPTY",
    }
    for msg, want in probes.items():
        d = t.decide(msg)
        seen[msg] = d.reason if not d.ok else f"PLAN:{d.intent}"
        assert seen[msg] == want, f"{msg!r} → {seen[msg]}（期望 {want}）"
    print(f"[PASS] 降级原因可区分 {len(probes)} 类场景（"
          f"{', '.join(sorted(set(seen.values()))) }）")


def test_decision_is_fast():
    """性能：快路径的意义是"0 次 LLM"，本地判定必须是毫秒级。"""
    t = tree()
    msgs = [m for m, _, _ in _GOLDEN] + [m for m in _MUST_DEFER]
    t.decide(msgs[0])                       # 预热
    t0 = time.perf_counter()
    n = 200
    for _ in range(n):
        for m in msgs:
            t.decide(m)
    avg = (time.perf_counter() - t0) * 1000 / (n * len(msgs))
    assert avg < 20, f"平均 {avg:.2f}ms，太慢"
    print(f"[PASS] 平均单次判定 {avg:.2f}ms（{len(msgs)} 条问句 × {n} 轮）")


def test_od_parser_equivalence_with_app():
    """等价性：默认起讫站解析与应用的 `app.od.parse_od` 必须一致。

    生产环境注入的是 `app.od.parse_od`（见 fastpath._provider），
    这里保证默认实现不会漂移。`app.od` 只依赖 re，可离线导入。
    """
    try:
        from app.od import parse_od as app_od
    except ImportError:
        print("[SKIP] 未找到 app.od（独立包环境）；该等价性测试需在仓库内运行")
        return

    corpus = [
        "北京到上海", "北京到上海走哪条线路？", "明天北京到上海还有票吗",
        "从北京去上海", "北京 上海", "北京南到济南西多少公里？",
        "上海虹桥到达屏", "陇海线全程多少公里？", "G1经停哪些站？",
        "换乘车站的编号怎么看？", "北京到北京", "明天下午到上海的高铁",
        "京沪高铁", "北京-上海", "北京→上海",
        # 下面几条是"默认实现曾与 app.od 漂移"的用例，必须留样
        "Z字头北京到上海有哪些", "北京到上海有哪些车",
        "北京到上海怎么走", "北京到上海需要中转吗",
    ]
    bad = []
    for text in corpus:
        a = app_od(text)
        b = app_od_parser(text)
        if a != b:
            bad.append(f"{text!r}: app={a} default={b}")
    assert not bad, "\n".join(bad)
    print(f"[PASS] 起讫站解析与 app.od 在 {len(corpus)} 条例子上完全一致")


def test_emu_model_longest_prefix():
    """车型归一：长前缀优先（CR400AF-AZ 不能被归成 CR400AF）。"""
    cases = {
        "CR400AF": "CR400AF",
        "CR400AF-AZ": "CR400AF-AZ",
        "CR400BF-BZ": "CR400BF-BZ",
        "CRH380AL": "CRH380AL",
        "CRH380A": "CRH380A",
        "CR200J-C": "CR200J-C",
        "CRH6A-A": "CRH6A-A",
    }
    for raw, want in cases.items():
        got = default_emu_model(raw)
        assert got == want, f"{raw} → {got}（期望 {want}）"
    assert default_emu_model("随便一句话") is None
    print(f"[PASS] 车型归一 {len(cases)} 例（最长前缀优先）")


def test_train_prefix_and_model_tables_consistent():
    """知识表自检：车次前缀表与车型表不能有重复键、字段必须齐。"""
    for p, meta in TRAIN_PREFIXES.items():
        assert {"zh", "emu", "note"} <= set(meta), (p, meta)
    for m, meta in EMU_FAMILIES.items():
        assert {"zh", "maker", "speed", "cars", "tags"} <= set(meta), (m, meta)
        assert isinstance(meta["cars"], list) and meta["cars"], (m, meta)
    print(f"[PASS] 知识表自检：车次前缀 {len(TRAIN_PREFIXES)} 类、"
          f"车型 {len(EMU_FAMILIES)} 族")


def test_unknown_input_never_crashes():
    """健壮性：任意输入都不得抛异常（快路径异常会拖垮整条流水线）。"""
    t = tree()
    hostile = ["", " ", "\n\n", "😀" * 50, "a" * 5000, "<script>x</script>",
               "1234567890", "G" * 100, "北京" * 200, "\x00\x01\x02",
               "CR400AF" * 50, "到" * 100, "？？？", "{}", "1.5", "NaN"]
    for msg in hostile:
        d = t.decide(msg)
        assert d.action in ("plan", "defer"), (msg, d)
        if not d.ok:
            assert d.reason in REASON_ZH, (msg, d.reason)
    print(f"[PASS] {len(hostile)} 条恶意/畸形输入均无异常且有明确结论")


def main():
    # 契约
    test_golden_cases_still_take_over()
    test_red_line_defer_cases()
    test_defer_always_has_structured_reason()
    # 回归
    test_fake_od_from_screen_word_is_rejected()
    test_train_type_prefix_not_confused_with_model_letters()
    test_od_endpoint_train_type_prefix_is_stripped()
    test_od_endpoint_question_frame_is_stripped()
    test_derived_filters_accumulate_in_extra()
    test_line_resolver_does_not_swallow_whole_sentence()
    test_wants_stops_is_not_triggered_by_quan_cheng()
    test_annotations_actually_fire()
    test_stops_sequence_keeps_exact_slot_contract()
    test_fake_station_no_longest_match()
    test_same_word_station_is_demoted()
    test_station_pick_is_deterministic()
    test_inherited_station_is_not_clobbered()
    test_tree_is_not_dag()
    # 结构
    test_all_tests_are_valid_and_describable()
    test_layer_order_is_safety_first()
    test_scale_over_1000_conditions()
    test_scale_grows_with_station_table()
    # 能力
    test_new_coverage_beyond_old_rules()
    test_multi_turn_inheritance()
    test_defer_reason_distribution()
    test_decision_is_fast()
    test_od_parser_equivalence_with_app()
    test_emu_model_longest_prefix()
    test_train_prefix_and_model_tables_consistent()
    test_unknown_input_never_crashes()
    st = tree_stats()
    print(f"\n铁路决策树测试全部通过 ✔  "
          f"（{st['total_conditions']} 个判断条件 / {st['nodes']} 节点 / "
          f"站点表 {st['n_stations']} 条·{st['station_source']}）")


if __name__ == "__main__":
    main()
