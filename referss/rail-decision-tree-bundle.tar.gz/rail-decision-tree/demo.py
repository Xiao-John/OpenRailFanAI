#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""铁路决策树 · 零依赖交互演示。

不需要装 fastapi / openai / 12306 依赖，也不需要网络：
决策树包本身零第三方依赖，站点表在 12306 站点库不可用时自动退到内置兜底表。

用法：
    python3 demo.py                       # 交互式
    python3 demo.py -q "G1经停哪些站？"     # 单句 + 完整判断轨迹
    python3 demo.py --probe               # 跑契约用例（9 条接管 + 8 条必须交回 AI）
    python3 demo.py --stats               # 只看树的规模

交互里可用命令：
    /trace   开关判断轨迹
    /stats   看树规模
    /probe   跑契约用例
    /quit    退出
"""
from __future__ import annotations

import argparse
import os
import sys

# ---- 兼容两种运行方式：仓库内（backend/app/...）或独立包（./rail_tree）----
_HERE = os.path.dirname(os.path.abspath(__file__))
for _cand in (
    os.path.join(_HERE, "..", "backend"),   # 仓库内 scripts/demo.py
    _HERE,                                  # 独立包（bundle 根目录）
):
    if os.path.isdir(os.path.join(_cand, "app", "pipeline", "rail_tree")) or \
       os.path.isdir(os.path.join(_cand, "rail_tree")):
        sys.path.insert(0, os.path.abspath(_cand))
        break

try:                                        # 仓库内
    from app.pipeline.rail_tree import RailTree
    from app.pipeline.rail_tree.build import REASON_ZH
except ImportError:                         # 独立包
    from rail_tree import RailTree                       # type: ignore
    from rail_tree.build import REASON_ZH                # type: ignore

C_HEAD, C_OK, C_NO, C_DIM, C_OFF = "\033[1;36m", "\033[32m", "\033[33m", "\033[2m", "\033[0m"

# 与 tests/test_perf_fastpath.py 逐条对齐的契约用例
GOLDEN = [
    ("G1经停哪些站？", "schedule"),
    ("G1今天由哪组动车组担当？", "emu_routing"),
    ("g1次列车今天的车底是啥？", "emu_routing"),
    ("明天北京到上海的高铁还有票吗？", "ticket"),
    ("北京南站大屏今天下午有哪些高铁？", "station"),
    ("北京南到济南西多少公里？", "rail_line"),
    ("陇海线全程多少公里？", "rail_line"),
    ("北京南站的电报码是多少？", "station"),
    ("上海虹桥到达屏", "station"),
]
MUST_DEFER = [
    "CR400AF用的哪个品牌的动力系统？",
    "CR400AF 和 CR400BF 有什么区别？",
    "和谐号和复兴号是什么关系？",
    "CR200J 为什么被叫绿巨人？",
    "沪苏湖高铁开通了吗？现在什么状态？",
    "帮我把这段话翻译成英文",
    "换乘车站的编号怎么看？",
    "G1今天几点到上海虹桥？",
]
# 旧快路径会交回 AI、现在能确定性判定的问法（体现增量）
NEW_COVER = [
    "北京到上海有哪些车", "明天北京到上海有哪些高铁", "G1明天还有商务座吗",
    "CR400BF今天跑哪些车次", "北京南站有几个站台", "京沪高铁全长多少公里",
    "Z字头北京到上海有哪些", "北京到上海走哪条线路",
    "北京到上海有没有夕发朝至的卧铺", "北京到上海最早一班是几点",
]

_TREE: RailTree | None = None


def tree() -> RailTree:
    global _TREE
    if _TREE is None:
        _TREE = RailTree()
    return _TREE


def show_stats() -> None:
    t = tree()
    st = {**t.stats, "n_stations": len(t.provider.get_index()),
          "station_source": t.provider.station_source()}
    print(f"{C_HEAD}铁路决策树规模{C_OFF}")
    print(f"  判断条件合计 : {st['total_conditions']}")
    print(f"    · 业务判断 : {st['conditions']}")
    print(f"    · 站点匹配 : {st['trie_conditions']}"
          f"（trie 节点：按「下一个字是不是 X」分支）")
    print(f"  节点总数     : {st['nodes']}    最大深度: {st['depth']}")
    print(f"  终态         : 接管 {st['plans']} / 降级 {st['defers']}")
    print(f"  站点表       : {st['n_stations']} 条（来源 {st['station_source']}）")
    print(f"  {C_DIM}说明：站点表越大，站点匹配子树越大；"
          f"生产实测（12306 站点库 3384 站）为 5329 个判断条件。{C_OFF}")


def report(msg: str, trace: bool = False) -> None:
    d = tree().decide(msg, explain=trace)
    if d.ok:
        print(f"  {C_OK}▶ 确定性接管{C_OFF}  intent = {C_HEAD}{d.intent}{C_OFF}"
              f"  （question_type = {d.qtype}，{d.elapsed_ms:.2f}ms）")
        print(f"    槽位 slots  = {d.slots}")
        if d.matched:
            print(f"    依据        = {', '.join(d.matched)}")
    else:
        print(f"  {C_NO}▶ 交回 AI{C_OFF}（不猜）  原因 = {C_HEAD}{d.reason}{C_OFF}")
        print(f"    {d.detail}")
        if d.matched:
            print(f"    已解析      = {', '.join(d.matched)}")
    if d.notes:
        print(f"    {C_DIM}备注: {'；'.join(d.notes)}{C_OFF}")
    if trace:
        print(f"    {C_DIM}判断轨迹（{len(d.trace)} 步）：{C_OFF}")
        for i, st in enumerate(d.trace, 1):
            mark = f"{C_OK}✔{C_OFF}" if st["hit"] else f"{C_DIM}✘{C_OFF}"
            print(f"      {i:>3}. {mark} {st['label']}  {C_DIM}[{st['test']}]{C_OFF}")


def run_probe() -> int:
    t = tree()
    bad = 0
    print(f"{C_HEAD}契约用例：原有快路径的 9 条黄金用例必须继续接管{C_OFF}")
    for msg, want in GOLDEN:
        d = t.decide(msg)
        ok = d.ok and d.intent == want
        bad += not ok
        print(f"  {'✔' if ok else '✘'} {msg:30s} → "
              f"{d.intent if d.ok else '交回 AI:' + d.reason}")
    print(f"\n{C_HEAD}红线：8 条知识型/时效型/无信号问题必须交回 AI{C_OFF}")
    for msg in MUST_DEFER:
        d = t.decide(msg)
        ok = not d.ok
        bad += not ok
        print(f"  {'✔' if ok else '✘'} {msg:34s} → "
              f"{'交回 AI（' + d.reason + '）' if not d.ok else '被接管 ' + d.intent}")
    print(f"\n{C_HEAD}新增覆盖：旧规则会交回 AI，现在可确定性判定{C_OFF}")
    for msg in NEW_COVER:
        d = t.decide(msg)
        print(f"  · {msg:30s} → "
              f"{d.intent + ' ' + str(d.slots.get('extra', ''))[:34] if d.ok else '交回 AI:' + d.reason}")
    total = len(GOLDEN) + len(MUST_DEFER)
    print(f"\n{C_OK if bad == 0 else C_NO}契约结果：{total - bad}/{total} "
          f"{'全部通过 ✔' if bad == 0 else '失败 ✘'}{C_OFF}")
    return bad


def main() -> int:
    ap = argparse.ArgumentParser(description="铁路决策树演示")
    ap.add_argument("-q", "--query", help="单句判定（打印完整判断轨迹）")
    ap.add_argument("--probe", action="store_true", help="跑契约用例")
    ap.add_argument("--stats", action="store_true", help="只看树规模")
    args = ap.parse_args()

    if args.stats:
        show_stats()
        return 0
    if args.query:
        print(f"{C_HEAD}你 > {C_OFF}{args.query}")
        report(args.query, trace=True)
        return 0
    if args.probe:
        return 1 if run_probe() else 0

    show_stats()
    print(f"\n{C_DIM}输入任意车迷问法试试；/trace 开关轨迹，/probe 跑契约，/stats 看规模，"
          f"/quit 退出{C_OFF}")
    print(f"{C_DIM}可以直接试：G1经停哪些站？ / 明天北京到上海还有票吗 / "
          f"北京南站大屏今天下午有哪些高铁 / CR400AF为什么叫复兴号{C_OFF}\n")
    trace = False
    while True:
        try:
            line = input(f"{C_HEAD}你 > {C_OFF}").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not line:
            continue
        if line in ("/quit", "/exit", "/q"):
            break
        if line == "/trace":
            trace = not trace
            print(f"{C_DIM}判断轨迹：{'开' if trace else '关'}{C_OFF}")
            continue
        if line == "/stats":
            show_stats()
            continue
        if line == "/probe":
            run_probe()
            continue
        report(line, trace=trace)
        print()
    print("再见 👋")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
