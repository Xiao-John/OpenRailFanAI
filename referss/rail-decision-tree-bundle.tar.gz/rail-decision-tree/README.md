# 铁路决策树（RailFanAI 确定性判定层）· 分享包

这是一份**可以立刻跑起来**的成果包：把 RailFanAI 的"快路径"（意图判定 + 槽位抽取）
从 7 条平铺正则，重写成了一棵由领域知识表编译出来的**决策树**。

> 核心特点：**零第三方依赖**。不需要装 fastapi / openai / 12306 依赖，也不需要网络，
> 就能完整跑测试、跑交互演示、看每一次判断的完整轨迹。

---

## 30 秒上手（不用装任何东西）

```bash
tar xzf rail-decision-tree-bundle.tar.gz
cd rail-decision-tree

python3 demo.py --stats                 # 看树规模
python3 demo.py --probe                 # 跑 17 条契约用例
python3 demo.py -q "G1经停哪些站？"       # 单句 + 完整判断轨迹
python3 demo.py                         # 交互式，随便问
```

交互里输入 `/trace` 打开轨迹，然后问 `明天北京到上海还有票吗`，
就能看到它一步一步走过哪些条件、命中了哪个问法家族、往槽位里放了什么。

```bash
python3 tests/test_rail_tree.py         # 29 组断言（离线全绿）
```

---

## 成果摘要（实测数字）

| 指标 | 数值 |
|---|---|
| **判断条件合计** | **5,329**（业务判断 195 + 站点匹配子树 5,131） |
| 站点表 | 3,384 站（12306 官方站点库）；离线兜底 517 站 |
| 节点总数 / 深度 | 5,525 / 102 |
| 问法家族 | 15 个 |
| 领域知识表 | 车次前缀 11 类、车型族 56 族、线路约 150 条 |
| 单次判定耗时 | **0.17ms**（离线）/ 0.4–16ms（真实应用含站点库） |

规模随站点表增长（离线兜底 517 站 → 1,026 个条件；官方 3,384 站 → 5,329 个）。

---

## 怎么工作

**判断层次序**（自上而下，越靠前越先判断）：

```
站点匹配 → 家族识别 → 输入卫生 → 越界 → 知识型/时效型红线
        → 冲突与歧义 → 家族矩阵（命中且槽位齐备才接管）→ 兜底降级
```

每个终态要么**接管**（0 次 LLM 调用），要么**交回 AI**，且带**结构化原因**：

```
KNOWLEDGE_OR_OPEN   为什么/区别/原理/参数（问题性质需模型判断）
FRESHNESS_UNSAFE    开通了吗/调图/停运（必须实时数据源，规则不承诺）
OUT_OF_SCOPE        翻译/写代码/闲聊
TRAIN_STATION_ARRIVAL  车次+车站+到点（到点口径需模型判断）
NO_SLOT             意图明确但缺关键槽位
STATION_AMBIGUOUS / MULTI_TRAIN / UNKNOWN_FAMILY / EMPTY ...
```

这就是"打不了包票就交给 AI"：降级不是兜底，而是一等公民——
可以按原因统计覆盖率，判断该补词表还是该补槽位。

---

## 验证证据（`evidence/` 目录，全是真实输出）

| 文件 | 内容 |
|---|---|
| `1-独立包测试.txt` | 离线 29 组断言全绿 |
| `2-demo契约用例.txt` | 17 条契约用例 17/17 通过 |
| `3-树规模.txt` | 离线兜底表下的规模 |
| `4a-应用自带测试-本实现.txt` | **应用自带 `test_perf_fastpath.py`：8/8 通过** |
| `4b-应用自带测试-原实现对照.txt` | 同一命令跑原实现：**第 1 条即失败（0/8）** |
| `4c-端到端对话.txt` | 真实 HTTP `/api/chat`：deterministic 命中 + 正确交回 AI |
| `5-真实站点库树规模.txt` | 官方站点库下 5,329 个判断条件 |
| `6-git提交.txt` | 3 个提交的完整改动统计 |

端到端那三条（真实取到了 12306 数据）：

| 输入 | 决策层 | 结果 |
|---|---|---|
| `G1经停哪些站？` | `deterministic`（13.5ms） | 取回真实图定时刻：G1 北京南→上海虹桥 经停 7 站含到发时刻 |
| `明天北京到上海还有票吗` | `deterministic`（0.4ms） | 真实余票：区间 54 趟 + 席别有票统计 |
| `换乘车站的编号怎么看？` | `llm-merged`（**交回 AI**） | 未编造；命中车站词表但匹配不到真实站名 → `NO_SLOT` 降级 |

---

## 目录结构

```
rail-decision-tree/
├── README.md                     ← 本文件
├── demo.py                       ← 零依赖交互演示
├── rail-decision-tree.patch       ← 应用到 RailFanAI 仓库（3 个提交）
├── rail_tree/                    ← 决策树包本体（可独立导入）
│   ├── knowledge.py              领域知识表（条件来源）
│   ├── stations.py               站点兜底表
│   ├── text.py                   文本 → 事实（车次/车型/站名/区间/线路/时间/席别）
│   ├── nodes.py                  节点类型 + 测试 DSL + 走树 + 规模统计
│   ├── build.py                  由知识表编译整棵树
│   └── decide.py                 Decision（plan/defer + 原因 + 轨迹）
├── tests/test_rail_tree.py       29 组断言（离线可跑）
├── docs/rail-tree.md             设计文档（含 18 条真 bug 复盘）
└── evidence/                     真实验证输出
```

---

## 集成到 RailFanAI 仓库

```bash
cd <RailFanAI 仓库>
git apply /path/to/rail-decision-tree.patch     # 或 git am 保留提交信息
```

改动只有 13 个文件、约 4,000 行新增，其中本模块是**新增**的；
被修改的只有 `fastpath.py`（变薄适配层）、`tests/run_all.sh`、`docs/README.md`。

**兼容性保证**：`fastpath.plan()` / `FastPlan` / `_station_in_text()` / `_line_in_text()`
签名与语义完全不变，`planner.decide()` 无需改动；不新增 `Intent` 枚举值，
推荐类问法全部映射到既有意图，偏好条件写进 `slots.extra`（`retrieve` 与生成层都能读到）。

合并后跑：

```bash
bash backend/tests/run_all.sh                      # 全量（需装依赖）
PYTHONPATH=. python3 backend/tests/test_rail_tree.py   # 本模块离线套件
python3 scripts/rail_tree_report.py                # 诊断报告
```

---

## 值得一看的几个坑（完整 18 条在 `docs/rail-tree.md`）

1. **`app.od.parse_od("上海虹桥到达屏")` 返回 `("上海虹桥","达屏")`** ——
   把"到达屏"的"到"当成了区间分隔符。这是应用里既有的真 bug，
   假区间会污染 `Slots.direction`，让下游按错误区间去查。
2. **树被写成 DAG** —— 家族的 `no` 分支和槽位 fallthrough 引用了同一个后续节点，
   条件数虚高、判断轨迹失去可解释性。加了"cond id 唯一"校验直接报错。
3. **领域注记从未生效** —— `annotate()` 把 `{t,label}` 字典直接当测试传给求值器，恒判 False。
4. **链式构造顺序写反** —— 用"从内向外包裹"建链会让最先写的那层最后才判断，
   安全条件被话题条件短路。
5. **站点索引缓存把兜底表锁死** —— 站点库要先 `await ensure_loaded()`；
   在此之前取索引会把兜底表永久缓存，树按 1,026 而不是 5,329 编译。

---

## 已知局限

1. **不新增意图**：像"中转接续方案"这类问法只能映射到既有意图，
   偏好通过 `extra` 传给生成层，不走专门数据源。
2. **区间解析受 `app.od` 的端点长度上限影响**：树用"截断到框架词 + 二次尝试"缓解，
   个别长句仍会降级交回 AI（与改动前一致，不是回归）。
3. **注记是"先命中者胜"**：只放表驱动、天然互斥的注记；
   文本派生且可同时成立的筛选条件走 `Facts.extra_text()`（累加语义）。
4. 本地字典 `backend/data/dict.db` 需用 `python3 scripts/mirror_dict.py` 生成
   （境内网络），否则里程/车站档案类查询会退化——这是应用侧数据问题。
