# -*- coding: utf-8 -*-
"""决策树生成器。

把 `knowledge.py` 里的领域表 + 站点 trie 编译成**一棵纯数据的大树**。
树的规模随"站点表有多大"线性增长——生产环境用 12306 的 3384 站，
站点匹配子树就有数千个判断条件。

判断顺序（自外向内，越靠前越先判断）
------------------------------------
    0. scan  匹配站点（站点 trie 最长匹配 + 强弱分级）
    1. scan  识别问法家族
    2. clean  输入卫生：空 / 纯标点 / 纯数字 / 无中文 / 超长 / 链接 / 代码
    3. scope  越界：翻译、写代码、天气、闲聊…
    4. know   知识型红线：为什么/区别/原理/历史… + 时效性（开通了吗/调休/停运）
    5. conflict 冲突与歧义：假区间、车次+车站+到点、多站名、开行状态
    6. family 问法家族矩阵（按优先级逐个试：命中且槽位够 → 接管）
    7. hint   兜底：交出"最具体的降级原因"（缺哪个槽位的哪个家族）

为什么"顺序"要写得这么死
------------------------
上一个项目我在这里栽过：建链时用"从内向外包裹"，结果最先写的那层
变成最内层、最后才判断——安全条件被话题条件短路。所以这里用
`chain()` 显式表达顺序，并且 `stats()` 会校验树不是 DAG。
"""
from __future__ import annotations

import re

from .knowledge import (
    AMBIGUOUS_COMBOS, EMU_FAMILIES, FAMILIES, NO_EXTRA_FAMILIES,
    OPTIONAL_SLOT_ALIASES, SEAT_WORDS, TIME_WINDOW_WORDS, TRAIN_PREFIXES,
)
from .nodes import (
    TreeBuilder, make_defer, make_defer_best, make_plan, stats as node_stats,
)
from .text import DEFAULT_PROVIDER, Provider

# ==========================================================================
# 降级原因（会透出到日志/前端流程说明，便于统计"为什么叫了 AI"）
# ==========================================================================
REASON_ZH: dict[str, str] = {
    "EMPTY": "输入为空",
    "PURE_PUNCT": "只有标点",
    "PURE_DIGIT": "只有一个数字，无法判断是不是车次/年份",
    "NO_CHINESE": "没有中文内容",
    "TOO_LONG": "句子过长、成分复杂（超过 120 字）",
    "URL_OR_CODE": "含链接或代码，超出铁路助手范围",
    "OUT_OF_SCOPE": "与铁路出行无关（翻译/写代码/闲聊等）",
    "KNOWLEDGE_OR_OPEN": "知识型/开放型问题：问题性质需模型判断，规则不猜",
    "FRESHNESS_UNSAFE": "开通/停运/调图等时效问题：必须依赖实时数据源，规则不承诺",
    "SCHEDULE_CHANGE_UNSAFE": "临客/加开/停运等开行调整：需要实时数据，规则不承诺",
    "TRAIN_STATION_ARRIVAL": "车次 + 具体车站的到发时刻：到点口径需模型判断",
    "TRAIN_SIGN_STATUS": "车次是否开行/停运：必须实时数据源",
    "STATION_AMBIGUOUS": "句中出现多个站名，无法确定是哪一个（请补充出发站/到达站）",
    "OD_FAKE": "解析出的区间不可信（疑似把「到达屏」这类词当成车站）",
    "MULTI_TRAIN": "句中出现多个车次，无法确定查哪一个",
    "NO_SLOT": "意图明确但缺少关键槽位（车次/站名/区间/车型/线路）",
    "UNKNOWN_FAMILY": "没有匹配到任何已知问法",
    "TREE_TOO_DEEP": "判断步数超限（内部保护）",
    "NEWS_DEFER": "资讯类问题：需要实时检索与时效判断，交回 AI",
    "PROMISE_UNSAFE": "这类问题规则不宜承诺（需实时数据或模型判断）",
}

REASON_ORDER = list(REASON_ZH)


# ==========================================================================
# 链式构造：列表顺序 = 判断顺序
# ==========================================================================
def chain(b: TreeBuilder, items: list[tuple[dict, dict]], tail: dict) -> dict:
    """items 为 (测试, 命中后去向)，**列表顺序就是判断顺序**；tail 是全部不命中时的落点。"""
    node = tail
    for test, yes in reversed(items):
        label = test.get("label") or _test_label(test)
        node = b.cond(label, test["t"], yes, node)
    return node


def _test_label(test: dict) -> str:
    from .nodes import describe_test
    return describe_test(test["t"])


def T(kind: str, label: str, *args) -> dict:
    """构造一个测试描述（kind + 展示用 label + 参数）。"""
    return {"t": list((kind,) + args), "label": label}


# ==========================================================================
# 槽位配方（终态是纯数据，槽位值必须在运行时从 facts 解析）
# ==========================================================================
def recipe_for(fam: dict) -> dict:
    """按家族的 carriers 生成槽位配方。

    `extra` 是**有条件的**：它承载规范化筛选条件（时段/席别/车种）与领域注记，
    会被下游 `retrieve`（票/里程）与生成层 prompt 读取；但个别家族为了保持
    应用既有的严格槽位断言而不产出它，见 `NO_EXTRA_FAMILIES`。
    """
    r: dict = {"time": ["fact", "time_phrase"]}
    if fam.get("key") not in NO_EXTRA_FAMILIES:
        r["extra"] = ["extra"]
    for src, dst in (fam.get("carriers") or {}).items():
        if src == "train":
            r[dst] = ["fact", "train_code"]
        elif src == "station":
            r[dst] = ["fact", "station"]
        elif src == "emu":
            r[dst] = ["fact", "emu_model"]
        elif src == "line":
            r[dst] = ["fact", "line"]
        elif src == "od":
            r[dst] = ["od"]
    return r



def annotate(b: TreeBuilder, base: dict, items: list[tuple[dict, str]]) -> dict:
    """给一个 plan 挂上"领域注记"分支，使推荐结果带上权威的铁路知识。

    为什么值得占条件数：这些注记是**下游 LLM 写答案时的依据**。
    比如同样是 emu_routing，Z 字头（直达特快）没有公开的担当数据，
    而 G 字头有——不告诉模型，它就会一本正经地编一个车组号出来。
    车型族注记同理：把中文名/厂商/编组/速度等级喂给模型，
    比让它凭记忆写 CR400AF-A 是 8 辆编组要可靠得多。

    结构上必须是"线性挂载"：items 逆序包裹、no 一路指向 base，
    这样 base 只被引用一次（否则整棵树会变成 DAG）。
    """
    if base.get("t") != "plan":
        raise AssertionError(
            "annotate() 的 base 必须是 plan 节点：对 cond 做 dict(base) 浅拷贝会把 "
            "id/test/yes/no 一起复制出来，产生同 id 的第二个节点 → DAG。"
            "多组注记请合并成一个 items 列表一次性挂载。")
    node = base
    for test, note in reversed(items):
        # items 里给的是 T() 构造的 {t, label} 描述；eval_test 要的是 test["t"]
        # 本身。直接把 dict 传进去会恒判 False（踩过的坑：所有注记都"没命中"）。
        spec = test["t"] if isinstance(test, dict) and "t" in test else test
        nxt = dict(base)          # base 是 plan（无 id），浅拷贝安全
        nxt["note"] = note
        node = b.cond(f"注记：{note[:26]}", spec, nxt, node)
    return node


def _train_class_items() -> list[tuple[dict, str]]:
    """车次类型注记：告诉下游这是什么车种、有没有公开担当数据。"""
    out: list[tuple[dict, str]] = []
    for prefix, meta in TRAIN_PREFIXES.items():
        out.append((
            T("attr_eq", f"车次前缀={prefix}", "train_prefix", prefix),
            f"车种＝{meta['zh']}；{meta['note']}",
        ))
    out.append((
        T("attr_eq", "纯数字车次", "train_prefix", "#"),
        "车种＝普速旅客列车（纯数字）；无公开机车担当数据源",
    ))
    return out


def _emu_model_items() -> list[tuple[dict, str]]:
    """车型族注记：把权威车型信息交给下游，减少模型凭记忆编造参数。"""
    out: list[tuple[dict, str]] = []
    for model, meta in EMU_FAMILIES.items():
        cars = "/".join(str(c) for c in meta.get("cars", []))
        tags = "、".join(meta.get("tags", []))
        out.append((
            T("attr_eq", f"车型={model}", "emu_model", model),
            f"车型＝{meta['zh']}；制造＝{meta['maker']}；"
            f"设计时速≈{meta['speed']}km/h；编组={cars}辆"
            + (f"；特征={tags}" if tags else ""),
        ))
    return out


def _screen_dir_items() -> list[tuple[dict, str]]:
    return [
        (T("attr_eq", "大屏方向=出发", "screen_direction", "departure"),
         "大屏方向＝出发（只看始发/发车车次）"),
        (T("attr_eq", "大屏方向=到达", "screen_direction", "arrival"),
         "大屏方向＝到达（只看终到/到站车次）"),
    ]


# 哪些家族挂哪组注记（键对应 _ANNO_BUILDERS）。
#
# 只放**表驱动、天然互斥**的注记（车次前缀一对一、车型一对一、大屏方向二选一）：
# 注记链是"先命中者胜"，同一家族挂两组会互相遮蔽。
# 凡是**文本派生、可以同时成立**的筛选条件（时段/席别/夜车/首末班/中转），
# 一律放 `Facts.extra_text()`——那里是累加语义，不会互相覆盖。
ANNOTATIONS: dict[str, list[str]] = {
    "emu_routing_by_train": ["train_class"],
    "emu_routing_by_model": ["emu_model"],
    "train_timetable": ["train_class"],
    "ticket_by_train": ["train_class"],
    "station_screen": ["screen_dir"],
    "photo_spot": ["emu_model", "train_class"],
}

_ANNO_BUILDERS = {
    "train_class": _train_class_items,
    "emu_model": _emu_model_items,
    "screen_dir": _screen_dir_items,
}

# ==========================================================================
# 各层
# ==========================================================================
def layer_clean(b: TreeBuilder, tail: dict) -> dict:
    """输入卫生：这些输入不需要任何铁路判断，直接给出可读的降级原因。"""
    items = [
        (T("not", "输入非空", ["attr", "norm"]), make_defer("EMPTY", REASON_ZH["EMPTY"])),
        (T("flag", "只有标点", "pure_punct"), make_defer("PURE_PUNCT", REASON_ZH["PURE_PUNCT"])),
        (T("flag", "只有一个数字", "pure_digit"),
         make_defer("PURE_DIGIT", REASON_ZH["PURE_DIGIT"])),
        (T("len", "长度超过 120 字", ">", 120),
         make_defer("TOO_LONG", REASON_ZH["TOO_LONG"])),
        (T("flag", "含链接或代码", "url_like"),
         make_defer("URL_OR_CODE", REASON_ZH["URL_OR_CODE"])),
        (T("flag", "像代码", "code_like"),
         make_defer("URL_OR_CODE", REASON_ZH["URL_OR_CODE"])),
        # 没有中文、也没有车次号 → 不是中文铁路问法
        (T("all", "无中文且无车次",
           [["flag", "no_cjk"], ["not", ["train_known"]]]),
         make_defer("NO_CHINESE", REASON_ZH["NO_CHINESE"])),
    ]
    return chain(b, items, tail)


def layer_scope(b: TreeBuilder, tail: dict) -> dict:
    items = [
        (T("flag", "越界话题（翻译/代码/天气/闲聊）", "out_of_scope"),
         make_defer("OUT_OF_SCOPE", REASON_ZH["OUT_OF_SCOPE"])),
    ]
    return chain(b, items, tail)


def layer_knowledge(b: TreeBuilder, tail: dict) -> dict:
    """★ 红线：知识型 / 开放型 / 时效型问题一律交回 LLM。

    为什么放在这么靠前：这类问题的 **question_type**（realtime / knowledge / mixed）
    决定下游能不能用模型知识作答，规则猜错会把"据模型知识"标成"实时检索"，
    属于会误导用户的错误。宁可多叫一次 AI，也不猜。
    """
    items = [
        (T("flag", "知识型/开放型（为什么、区别、原理、参数…）", "knowledge"),
         make_defer("KNOWLEDGE_OR_OPEN", REASON_ZH["KNOWLEDGE_OR_OPEN"])),
        (T("flag", "比较型（区别、哪个好）", "compare"),
         make_defer("KNOWLEDGE_OR_OPEN", REASON_ZH["KNOWLEDGE_OR_OPEN"])),
        (T("flag", "时效型（开通了吗、调图、停运…）", "freshness"),
         make_defer("FRESHNESS_UNSAFE", REASON_ZH["FRESHNESS_UNSAFE"])),
    ]
    return chain(b, items, tail)


def layer_conflict(b: TreeBuilder, tail: dict) -> dict:
    """冲突与歧义：能识别但**不该承诺**的情况，交回 AI 并说明原因。"""
    items: list[tuple[dict, dict]] = []

    # 1) 车次 + 具体车站 + 到发时刻 → 到点口径需模型判断
    for combo in AMBIGUOUS_COMBOS:
        tests: list = []
        for need in combo["need"]:
            tests.append(["attr", {
                "train": "train_code", "station": "station", "od": "od",
                "line": "line", "emu": "emu_model",
            }.get(need, need)])
        tests.append(["re_any", combo["words"]])
        items.append((
            T("all", f"冲突：{combo['desc']}", tests),
            make_defer(combo.get("reason", "PROMISE_UNSAFE"), combo["desc"]),
        ))

    # 2) 多个站名且没有区间来消解 → 歧义
    items.append((
        T("ambiguous_station", "多个站名且无区间",
          "ambiguous_station"),
        make_defer("STATION_AMBIGUOUS", REASON_ZH["STATION_AMBIGUOUS"]),
    ))

    # 3) 假区间（"上海虹桥到达屏" 被解析成 "上海虹桥→达屏" 这类）
    items.append((
        T("flag", "区间不可信", "od_fake"),
        make_defer("OD_FAKE", REASON_ZH["OD_FAKE"]),
    ))

    # 4) 多个车次
    items.append((
        T("hits", "出现多个车次", "train_codes", ">=", 2),
        make_defer("MULTI_TRAIN", REASON_ZH["MULTI_TRAIN"]),
    ))

    # 5) 开行调整（临客/加开/停运）且没有区间可查 → 不承诺
    items.append((
        T("all", "开行调整且无区间",
           [["flag", "schedule_change"], ["no_od"]]),
        make_defer("SCHEDULE_CHANGE_UNSAFE", REASON_ZH["SCHEDULE_CHANGE_UNSAFE"]),
    ))
    return chain(b, items, tail)


# 槽位 → "事实是否具备"的测试。
# ⚠️ 这里**必须**读 facts，不能读 ctx.slots：ctx.slots 是走完树之后才填的
# 输出容器，遍历期间恒为空——用它做充分性判断会让所有家族都"缺槽位"。
SLOT_TEST: dict[str, list] = {
    "train": ["has_train"],
    "station": ["has_station"],
    "od": ["has_od"],
    "line": ["has_line"],
    "emu": ["has_emu"],
}


def _slot_alternatives(slot_spec) -> list:
    """把家族声明的一项槽位需求转成"或"测试。

    `slots` 支持两种写法：
        "train"                单槽位
        ["station", "od"]      任一即可
    """
    names = slot_spec if isinstance(slot_spec, list) else [slot_spec]
    resolved: list[str] = []
    for n in names:
        resolved.extend(OPTIONAL_SLOT_ALIASES.get(n, (n,)))
    return [SLOT_TEST[n] for n in resolved if n in SLOT_TEST]


def layer_families(b: TreeBuilder, tail: dict) -> dict:
    """问法家族矩阵：按 FAMILIES 顺序逐个尝试，**先命中且槽位齐备者胜**。

    每个家族只生成**一个**条件（家族命中 ∧ 槽位齐备），`no` 指向下一个家族。
    这样整条链是线性的，不会出现"同一个后续节点被引用两次"的 DAG。

    为什么不用"命中家族 → 再逐槽位判断、缺槽位就 fallthrough"那种更"自然"的写法：
    那条路径会让每个槽位的 fallthrough 和家族条件的 no 指向同一个节点，
    父节点被引用多次 → 树变成 DAG → 条件数虚高、判断轨迹失去可解释性。
    "缺哪个槽位"的信息改由前置的 `plan_hints` scan 统一记录。
    """
    node = tail
    for fam in reversed(FAMILIES):
        key = fam["key"]

        # 注定交回 AI 的家族（资讯/时效类）：显式建枝，只为说明降级原因
        if fam.get("defer"):
            node = b.cond(f"问法家族＝{key}", ["family_hit", key],
                          make_defer(fam["defer"],
                                     fam.get("desc") or REASON_ZH.get(fam["defer"], "")),
                          node)
            continue

        plan = make_plan(
            fam["intent"], fam.get("qtype", "realtime"),
            recipe_for(fam), reason=f"家族={key}", matched=[f"family={key}"],
            note=fam.get("note", ""),
            emit_extra=key not in NO_EXTRA_FAMILIES,
        )
        # 领域注记：所有注记组**合并成一次**挂载（base 必须是 plan，见 annotate）
        anno_items: list[tuple[dict, str]] = []
        for anno_key in ANNOTATIONS.get(key, []):
            anno_items.extend(_ANNO_BUILDERS[anno_key]())
        body = annotate(b, plan, anno_items) if anno_items else plan

        # 家族专属红线放在最外层：问了车次时刻、同时又给了具体车站 → 到点口径需模型判断
        if fam.get("defer_if_station"):
            body = b.cond(
                "车次问时刻时是否还给了具体车站", ["attr", "station"],
                make_defer("TRAIN_STATION_ARRIVAL",
                           REASON_ZH["TRAIN_STATION_ARRIVAL"]),
                body,
            )

        slots = fam.get("slots") or []
        tests: list = [["family_hit", key]]
        label = f"家族={key}"
        if slots:
            names = "+".join("/".join(sp if isinstance(sp, list) else [sp])
                             for sp in slots)
            for sp in slots:
                tests.append(["any", _slot_alternatives(sp)])
            label = f"家族={key} 且槽位齐备（{names}）"
        node = b.cond(label, ["all", tests] if len(tests) > 1 else tests[0],
                      body, node)
    return node


# ==========================================================================
# 主构建
# ==========================================================================
def build_tree(provider: Provider | None = None) -> dict:
    """编译整棵树。provider 决定站点表规模（生产用 12306 站点库）。"""
    p = provider or DEFAULT_PROVIDER
    b = TreeBuilder()

    # 由内向外包裹 → LAYER_ORDER 里靠前的层最终在最外层（最先判断）
    node = make_defer_best()
    node = layer_families(b, node)
    # 家族链之前统一预判"最高优先级命中家族缺哪个槽位"（供 defer_best 使用）
    node = b.scan("预判各家族的槽位缺口", "plan_hints", node, {"families": FAMILIES})
    node = layer_conflict(b, node)
    node = layer_knowledge(b, node)
    node = layer_scope(b, node)
    node = layer_clean(b, node)

    # 头部：先把事实抽出来（站点匹配与家族识别都进判断轨迹）
    node = b.scan("识别问法家族", "probe_families", node, {"families": FAMILIES})
    node = b.scan("匹配站点（trie 最长匹配）", "stations", node,
                  {"trie": p.get_trie()})
    return node


LAYER_ORDER = ["stations", "probe_families", "clean", "scope", "knowledge",
               "conflict", "plan_hints", "family", "hint"]


def build_report(provider: Provider | None = None) -> dict:
    """构建并返回规模报告（供 CLI/文档使用）。"""
    p = provider or DEFAULT_PROVIDER
    tree = build_tree(p)
    st = node_stats(tree)
    st["station_source"] = p.station_source()
    st["n_stations"] = len(p.get_index())
    st["layer_order"] = LAYER_ORDER
    st["n_families"] = len(FAMILIES)
    st["families"] = [f["key"] for f in FAMILIES]
    return st


__all__ = ["build_tree", "build_report", "REASON_ZH", "REASON_ORDER",
           "LAYER_ORDER", "chain", "T", "recipe_for"]
