# -*- coding: utf-8 -*-
"""铁路决策树（RailFanAI 的确定性判定层）。

用法：
    from app.pipeline.rail_tree import RailTree, Provider

    tree = RailTree()                     # 生产：默认注入应用的真实解析器
    d = tree.decide("G1经停哪些站？")
    if d.ok:
        ...  # 0 次 LLM 调用，直接用 d.intent / d.slots
    else:
        ...  # 交回 AI，d.reason / d.detail 说明为什么

模块内**不导入任何第三方库**（fastapi/pydantic/mcp_12306 都不依赖），
因此可以脱离运行环境做完整单测；与应用的对接只在 `fastpath.py` 一层。
"""
from .build import REASON_ZH, build_report, build_tree, LAYER_ORDER
from .decide import Decision, RailTree, decide, get_default_tree
from .nodes import describe_test, stats as tree_stats, walk
from .text import Facts, Provider, extract, flags_of

__all__ = [
    "RailTree", "Decision", "decide", "get_default_tree",
    "build_tree", "build_report", "tree_stats", "walk", "describe_test",
    "Provider", "Facts", "extract", "flags_of", "REASON_ZH", "LAYER_ORDER",
]
