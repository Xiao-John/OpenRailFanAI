# -*- coding: utf-8 -*-
"""文本特征抽取（零依赖、可注入）。

职责：把一句自然语言变成决策树可以判断的**事实集合**——
车次号、车型、站名、区间、线路、时间、席别、车种偏好、问法标记。

为什么要有"可注入的外部能力"
----------------------------
应用里已经有这些能力的权威实现：
    app.od.parse_od                                 起讫站解析
    app.tools._rt12306.extract_train_code           车次号（含"G1次列车"）
    app.tools._rt12306.all_stations                 12306 站点库（3384 站）
    app.pipeline.fastpath._line_in_text             线路名（经本地线路库校验）

但它们的**可导入性不同**：`app.od` 只依赖 re；`_rt12306` 依赖 mcp_12306；
`app.data.dict` → `app.config` 依赖 pydantic_settings。
于是本模块把四者都做成 `Provider` 上的可注入函数：

* **生产**：适配层注入真实实现 → 行为与改动前一致（便于回归对照）；
* **离线/单测**：用本模块的默认实现 → 无需网络与第三方依赖即可跑完整判定；
* 默认实现与真实实现在关键语义上对齐，并由 `tests/test_rail_tree.py`
  中的**等价性测试**钉住（拿 `app.od.parse_od` 当参照物逐例比对）。

这样做的代价是"两套实现"，但收益是：树的判定逻辑可以被完整、快速地测试，
而不是只能靠"跑起来看"。对一个要在生产里做路由的东西，这个交换是值得的。
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Callable

from .knowledge import (
    DATE_WORDS, EMU_BRANDS, EMU_FAMILIES, EMU_TRAIT_WORDS, FRESHNESS_HINTS,
    KNOWLEDGE_HINTS, LINE_ALIASES, LINES, OUT_OF_SCOPE_HINTS, SEAT_TAG,
    SEAT_WORDS, TIME_WINDOW_TAG, TIME_WINDOW_WORDS, TRAIN_PREFIXES,
    TRAIN_PREFIX_ALIASES, TRAIN_TYPE_PREF_TAG, TRAIN_TYPE_PREF_WORDS,
    WEEKDAY_WORDS,
)
from .stations import fallback_index

# ==========================================================================
# 具名正则（树的条件可以按名字引用，便于 JSON 化与解释）
# ==========================================================================
PATTERNS: dict[str, re.Pattern] = {
    "train_full": re.compile(r"^0?[GDCTZKYSLBN]\d{1,5}[A-Z]?$", re.I),
    "train_in_text": re.compile(r"(0?[GDCTZKYSLBN]\d{1,4}[A-Z]?)(?![A-Za-z0-9])", re.I),
    "train_digit_ci": re.compile(r"(?<!\d)(\d{1,4})(?=次(?:列车|车)?)"),
    "year_like": re.compile(r"^(?:19|20)\d{2}$"),
    # 车型串。约束（都是实测踩过的）：
    #   · 数字 1–4 位："CRH6A"/"CRH2A" 是**单数字**，用 {2,4} 会整类漏掉；
    #   · 字母后缀 0–3 位，且短横线后也要允许 1–3 位：
    #     "CR400AF-AZ"/"CR400BF-BZ" 的后缀是两个字母，只允许 1 位会被截成 -A；
    #   · 末尾车组号（CR400BFA5159 的 5159）由 {0,3} 自然截断。
    "emu_model": re.compile(r"(CRH?\d{1,4}[A-Za-z]{0,3}(?:-[A-Za-z]{1,3})?)", re.I),
    "line_token": re.compile(
        r"([\u4e00-\u9fa5]{2,8}?(?:高速|客运专线|客专|城际|高铁|铁路|线))"),
    "clock": re.compile(r"(\d{1,2})\s*[:：点]\s*(\d{1,2})?"),
    "date_iso": re.compile(r"(\d{4})[-/年](\d{1,2})[-/月](\d{1,2})[日号]?"),
    "month_day": re.compile(r"(\d{1,2})月(\d{1,2})[日号]"),
    "station_suffix": re.compile(r"站"),
    "pure_punct": re.compile(r"^[\s\W_]+$"),
    "pure_digit": re.compile(r"^\d+$"),
    "html_or_url": re.compile(r"(https?://|www\.|<[a-z/])", re.I),
    "code_like": re.compile(r"(def |import |function |class |\{|\}|;\s*$|</?[a-z]+>)", re.I),
    "has_cjk": re.compile(r"[\u4e00-\u9fa5]"),
}

# 站名"强上下文"：这些词紧邻站名时，说明它确实是站名而非普通词
# （用于压制"日照时间长""东方明珠""中山路"这类误匹配）
STATION_CONTEXT_BEFORE = ("去", "到", "在", "从", "往", "经", "回", "抵", "由",
                          "停", "始发", "终到", "路过", "换乘", "到达", "出发",
                          "位于", "属于")
STATION_CONTEXT_AFTER = ("站", "出发", "到达", "始发", "终到", "发车", "到站",
                         "下车", "上车", "大屏")


# ==========================================================================
# 默认实现（离线可用）
# ==========================================================================
def default_train_code(v: str | None) -> str | None:
    """车次号提取——语义对齐 `app.tools._rt12306.extract_train_code`。

    "G1次列车"→G1；"K53"→K53；"1461次列车"→1461；"CR400AF"→None；"2026"→None
    """
    if not v:
        return None
    s = str(v).strip()
    if PATTERNS["year_like"].match(s):
        return None
    if PATTERNS["train_full"].match(s):
        return s.upper()
    m = PATTERNS["train_in_text"].search(s)
    if m:
        return m.group(1).upper()
    m = PATTERNS["train_digit_ci"].search(s)     # 纯数字必须后接"次"
    if m:
        return m.group(1).upper()
    return None


def default_emu_model(text: str | None) -> str | None:
    """车型识别：先抽模型串，再按已知车型族做**最长前缀**归一。

    这样 "CR400AF-AZ" 不会被误判成 "CR400AF"（长前缀优先），
    "CR400BFA5159"（车组号）也能归到 CR400BF-A 或 CR400BF。
    """
    if not text:
        return None
    m = PATTERNS["emu_model"].search(str(text))
    if not m:
        return None
    raw = m.group(1).upper()
    # 去掉车组号后缀（CR400BFA5159 → CR400BFA）
    cand = re.sub(r"(?<=[A-Z])\d{3,4}$", "", raw)
    for key in sorted(EMU_FAMILIES, key=len, reverse=True):
        k = key.upper()
        if cand == k or cand.startswith(k) or raw.startswith(k):
            return key
    return None


def default_line_resolver(text: str | None) -> str | None:
    """识别线路名候选（别名优先，其次合法线路名，最后形态匹配）。

    只做**识别**：线路是否真实存在由下游 `app.data.dict` 校验，
    树不为此背书（失败只会让 retrieve 走它原有的兜底说明）。
    """
    if not text:
        return None
    s = str(text)
    # 1) 别名（"陇海铁路"→"陇海线"）
    for alias, canon in LINE_ALIASES.items():
        if alias in s:
            return canon
    # 2) 已知线路名（长的优先，避免"京沪线"抢走"京沪高铁"）
    for name in sorted(LINES, key=len, reverse=True):
        if name in s:
            return name
    # 3) 形态匹配（"XX线/XX高铁/XX客专"）——交给下游校验
    #
    # ⚠️ 这一步必须严格，否则会把整句吞成线路名。实测踩到：
    #     "明天北京到上海的高铁还有票吗？" → 线路="明天北京到上海的高铁"
    #     "北京南站大屏今天下午有哪些高铁？" → 线路="屏今天下午有哪些高铁"
    #   于是 extra 里出现一个根本不存在的"线路"，还被塞给下游。
    #   约束：候选 3–6 字，且不含方位/疑问/时段等功能词。
    for m in PATTERNS["line_token"].finditer(s):
        cand = m.group(1)
        if not (3 <= len(cand) <= 6):
            continue
        if _LINE_NOISE_CHARS.search(cand):
            continue
        return cand
    return None


# 线路名里不该出现的功能词（出现即说明是把整句切下来了）
_LINE_NOISE_CHARS = re.compile(
    r"(到|至|去|从|往|走|坐|乘|的|了|多少|怎么|怎样|哪|什么|有|没有|在|拍|"
    r"今天|明天|昨天|后天|上午|下午|晚上|早上|中午|点|分钟|小时|吗|呢|吧)")


def default_od(text: str | None) -> tuple[str, str] | None:
    """起讫站解析——语义对齐 `app.od.parse_od`（生产环境会注入后者）。"""
    if not text:
        return None
    s = str(text).strip()
    while s:
        before = s
        s = re.sub(r"^(?:今天|今日|明天|明日|昨天|昨日|前天|后天|大后天|"
                   r"本[周月日]|这[周月日]|下[周月日]|上[周月日]|"
                   r"周[一二三四五六日天]|星期[一二三四五六日天]|周末|"
                   r"凌晨|早上|早晨|上午|中午|下午|晚上|晚间|夜里|夜间|傍晚)"
                   r"[\s,，、]*", "", s).strip()
        s = re.sub(r"[\s？?。！!，,、；;：:~～—－\-]+$", "", s).strip()
        if s == before:
            break
    for pat in (
        re.compile(r"^(?P<f>[\u4e00-\u9fa5A-Za-z]{2,10}?)\s*"
                   r"(?:到|至|→|->|—|－|-|~|～)\s*(?P<t>[\u4e00-\u9fa5A-Za-z]{2,10})$"),
        re.compile(r"^从(?P<f>[\u4e00-\u9fa5A-Za-z]{2,10}?)\s*去\s*(?P<t>[\u4e00-\u9fa5A-Za-z]{2,10})$"),
        re.compile(r"^(?P<f>[\u4e00-\u9fa5A-Za-z]{2,10}?)\s*去\s*(?P<t>[\u4e00-\u9fa5A-Za-z]{2,10})$"),
    ):
        m = pat.match(s)
        if m:
            f = _trim_station(m.group("f").strip())
            t = _trim_station(m.group("t").strip())
            if not _timeish(f) and not _timeish(t) and f and t:
                return f, t
    return None


# 与 app.od._STATION_STOP_WORDS 对齐：截掉贪婪匹配吞进来的追问短语
# （"上海有哪些"→上海、"上海怎么走"→上海）。
# 不做这一步，独立包环境（没有 app.od 时回退到本实现）会在
# "Z字头北京到上海有哪些" 上给出 ("北京","上海有")。
_OD_STOP_WORDS = ("怎么", "如何", "走哪", "走", "几点", "多少", "多远", "要多久",
                  "多长时间", "呢", "吗", "吧", "啊", "的", "都", "有", "还有",
                  "开", "发车", "到达", "哪些", "哪个", "哪里", "什么时候")


def _trim_station(v: str) -> str:
    cut = len(v)
    for w in _OD_STOP_WORDS:
        i = v.find(w)
        if 0 < i < cut:
            cut = i
    return v[:cut].strip() or v


_TIMEISH_RE = re.compile(
    r"^(?:今天|今日|明天|明日|昨天|昨日|前天|后天|大前天|大后天|"
    r"本[周月日]|这[周月日]|下[周月日]|上[周月日]|周[一二三四五六日天]|"
    r"星期[一二三四五六日天]|周末|凌晨|早上|早晨|上午|中午|下午|晚上|"
    r"晚间|夜里|夜间|傍晚|今年|明年|去年|\d+[点时]|\d+月\d+[日号])")


def _timeish(v: str) -> bool:
    return bool(_TIMEISH_RE.match((v or "").strip()))


# ==========================================================================
# 站点 trie
# ==========================================================================
def build_station_trie(names: list[str]) -> dict:
    """把站名表构造成 trie。每个节点 = 一个"下一个字符是不是 X"的判断条件。"""
    root: dict = {"ch": {}, "end": None}
    for name in names:
        n = str(name).strip()
        if not (2 <= len(n) <= 8):
            continue
        node = root
        for c in n:
            node = node["ch"].setdefault(c, {"ch": {}, "end": None})
        node["end"] = n
    return root


def trie_scan(root: dict, text: str) -> list[dict]:
    """在文本里做**最长匹配**扫描，返回不重叠的命中列表。

    返回 `[{name, start, end}]`，按位置升序。
    与"遍历所有站名做 in 判断"相比，这里的语义是确定的：
    * 同一位置多个候选时取最长（北京南 优先于 北京）；
    * 命中后从匹配结束位置继续（不重叠），避免"北京南"里再报一个"北京"。
    """
    hits: list[dict] = []
    i, n = 0, len(text)
    while i < n:
        node = root
        best: str | None = None
        best_end = i
        j = i
        while j < n:
            node = node["ch"].get(text[j])
            if node is None:
                break
            j += 1
            if node["end"]:
                best = node["end"]
                best_end = j
        if best:
            hits.append({"name": best, "start": i, "end": best_end})
            i = best_end
        else:
            i += 1
    return hits


def hit_strength(text: str, name: str, start: int, end: int) -> str:
    """判断一个站名命中是"强"还是"弱"。

    为什么要这个：站点表里有大量**同时也是普通词**的站名
    （东方/中山/北海/白银/黄山/白山/日照/开封/天水…）。
    单纯"子串命中就算站名"会把"日照时间长""东方明珠""中山路"当成车站。
    旧实现（`max(hits, key=len)`）也有这个问题，只是没被触发。

    规则：满足任一条判为"强"
      1. 站名长度 ≥ 3（短名才会与普通词混淆）；
      2. 文本里紧跟"站"或其它站点语境词；
      3. 前面紧邻"去/到/在/从/往/经…"这类方位动词；
      4. 整个输入恰好就是站名本身。
    """
    if len(name) >= 3:
        return "strong"
    if text.strip() == name:
        return "strong"
    after = text[end:end + 3]
    if any(after.startswith(w) for w in STATION_CONTEXT_AFTER):
        return "strong"
    before = text[max(0, start - 3):start]
    if any(before.endswith(w) for w in STATION_CONTEXT_BEFORE):
        return "strong"
    return "weak"


# ==========================================================================
# 事实集合
# ==========================================================================
@dataclass
class Facts:
    text: str = ""
    norm: str = ""                       # 去空白、去首尾标点
    flags: set[str] = field(default_factory=set)
    train_codes: list[str] = field(default_factory=list)
    train_code: str | None = None
    train_prefix: str | None = None      # G/D/C/Z/... （纯数字车次为 "#"）
    train_class: dict | None = None      # TRAIN_PREFIXES 的一项
    emu_models: list[str] = field(default_factory=list)
    emu_model: str | None = None
    emu_traits: list[str] = field(default_factory=list)
    emu_brand: str | None = None         # 复兴号 / 和谐号
    station_hits: list[dict] = field(default_factory=list)
    stations: list[str] = field(default_factory=list)          # 全部命中（去重）
    strong_stations: list[str] = field(default_factory=list)
    station: str | None = None
    station_ambiguous: bool = False
    od: tuple[str, str] | None = None
    line: str | None = None
    date_word: str | None = None
    weekday_word: str | None = None
    window_word: str | None = None
    clock: str | None = None
    date_iso: str | None = None
    month_day: str | None = None
    time_phrase: str | None = None
    seat: str | None = None
    train_type_pref: str | None = None
    screen_direction: str | None = None
    wants_stops: bool = False
    wants_mileage: bool = False
    wants_night: bool = False          # 夕发朝至 / 夜车
    wants_first_last: bool = False     # 首班 / 末班 / 最早 / 最晚
    wants_transfer: bool = False       # 中转 / 换乘 / 接续
    rstrip_len: int = 0
    station_source: str = "unknown"      # official / fallback / none

    def to_slots(self) -> dict:
        """转成 `Slots` 的字段字典（适配层再包成 app 的 Slots）。"""
        return {k: v for k, v in {
            "location": self.station or (self.od[0] if self.od else None),
            "target": self.train_code or self.emu_model or self.line,
            "time": self.time_phrase,
            "direction": f"{self.od[0]}→{self.od[1]}" if self.od else None,
            "extra": self.extra_text(),
        }.items() if v}

    def extra_text(self) -> str | None:
        """把解析出来的筛选条件压成一句人类可读的补充说明。

        约定：只放下游/生成层**认得出**的词（与 retrieve.py 的口径一致），
        例如时段用「下午」、席别用「二等座」、车种用「普速」。
        """
        parts: list[str] = []
        if self.od:
            parts.append(f"区间 {self.od[0]} 到 {self.od[1]}")
        if self.line:
            parts.append(f"线路 {self.line}")
        # 以下"筛选条件"都带前缀：既让人一眼看懂，也不破坏下游的
        # 子串匹配口径（retrieve 的 _parse_seat/_parse_time_window/
        # _parse_train_type 都是 `词 in blob`，前缀不影响它们）。
        if self.window_word:
            parts.append(f"时段筛选：{self.window_word}")
        if self.clock:
            parts.append(f"开车时刻约 {self.clock}")
        if self.wants_night:
            parts.append("时段筛选：夜间（夕发朝至），优先卧铺/动卧")
        if self.wants_first_last:
            parts.append("班次偏好：首末班")
        if self.wants_transfer:
            parts.append("需要中转/换乘方案")
        if self.seat:
            parts.append(f"席别筛选：{self.seat}")
        if self.train_type_pref:
            parts.append(f"车种筛选：{self.train_type_pref}")
        if self.emu_model:
            parts.append(f"车型 {self.emu_model}")
        for t in self.emu_traits:
            parts.append(t)
        if self.train_prefix and self.train_class:
            parts.append(self.train_class["zh"])
        if self.wants_stops:
            parts.append("需要经停站序")
        if self.wants_mileage:
            parts.append("问里程")
        if self.screen_direction:
            parts.append("出发" if self.screen_direction == "departure" else "到达")
        return "；".join(parts) if parts else None


# ==========================================================================
# Provider：可注入的外部能力
# ==========================================================================
def app_od_parser(text: str) -> tuple[str, str] | None:
    """优先复用应用的 `app.od.parse_od`（它只依赖 re，可安全导入）。

    为什么优先用它而不是本模块的 `default_od`：起讫站解析在应用里已有权威
    实现（并带着一串回归修复：D09 时间词误判、F01 句末标点、F07 同站对…）。
    复用它可以**彻底消除两套实现漂移**的风险；`default_od` 只作为
    把本模块拿到 app 之外使用时的兜底。
    """
    try:
        from app.od import parse_od as _p
    except Exception:  # noqa: BLE001 —— 脱离 app 使用时退回本地实现
        return default_od(text)
    try:
        return _p(text)
    except Exception:  # noqa: BLE001
        return default_od(text)


@dataclass
class Provider:
    od_parser: Callable[[str], tuple[str, str] | None] = app_od_parser
    train_code_parser: Callable[[str], str | None] = default_train_code
    station_index: Callable[[], dict[str, dict]] = fallback_index
    line_resolver: Callable[[str], str | None] = default_line_resolver
    emu_model_parser: Callable[[str], str | None] = default_emu_model
    # 缓存：站点索引与 trie 只建一次（站点表 3384 条，别每次问答都重建）
    _index_cache: dict | None = field(default=None, repr=False, compare=False)
    _trie_cache: dict | None = field(default=None, repr=False, compare=False)
    _index_is_official: bool = field(default=False, repr=False, compare=False)

    def get_index(self) -> dict[str, dict]:
        """站点索引，支持"兜底表 → 官方库"**升级**。

        为什么需要升级：站点库（12306，3384 站）要先 `await ensure_loaded()` 才可用。
        如果在加载完成前就取了索引，就会把**兜底表**（517 站）永久缓存下来——
        树会以兜底规模编译，之后即使站点库就绪也不会变大。
        实测踩到：直接调 `tree_stats()` 时显示 1026 个条件，而正常问答流程下是 5329。
        所以只要当前缓存不是官方库，就再问一次；拿到更大的索引就替换并让 trie 失效。
        """
        if self._index_cache is None or not self._index_is_official:
            try:
                fresh = self.station_index() or {}
            except Exception:  # noqa: BLE001
                fresh = {}
            if fresh and (self._index_cache is None
                          or len(fresh) > len(self._index_cache)):
                self._index_cache = fresh
                first = next(iter(fresh.values()), {})
                self._index_is_official = first.get("source") != "fallback"
                self._trie_cache = None          # 索引变了，trie 必须重建
        if self._index_cache is None:
            self._index_cache = {}
        return self._index_cache

    def get_trie(self) -> dict:
        if self._trie_cache is None:
            self._trie_cache = build_station_trie(list(self.get_index().keys()))
        return self._trie_cache

    def station_source(self) -> str:
        idx = self.get_index()
        if not idx:
            return "none"
        first = next(iter(idx.values()))
        return "fallback" if first.get("source") == "fallback" else "official"


DEFAULT_PROVIDER = Provider()


def match_stations(f: Facts, trie: dict, *, keep_if_empty: bool = True) -> None:
    """对 facts.norm 做站点最长匹配，填强弱分级字段。

    单独抽出来是因为它在树里作为一个 `scan` 节点执行：
    轨迹里能看到"匹配站点"这一步，条件统计也能如实计入 trie 节点数。

    `keep_if_empty` 很关键：多轮继承是**先**把上轮的站名填进 facts，**再**走树；
    而走树时这个 scan 会重新匹配**本次**文本。若本次文本里没有站名，
    直接覆盖就会把继承来的站名清空——实测 "北京南站" → "大屏呢"
    这样本该成立的追问会因此降级。
    语义定为"本次命中优先，本次没有则保留已有"，即只填缺失。
    """
    if not f.norm or not trie or not trie.get("ch"):
        return
    hits = trie_scan(trie, f.norm)
    if not hits and keep_if_empty and (f.station_hits or f.station):
        return
    f.station_hits = hits
    for h in f.station_hits:
        h["strength"] = hit_strength(f.norm, h["name"], h["start"], h["end"])
    f.stations = list(dict.fromkeys(h["name"] for h in f.station_hits))
    f.strong_stations = list(dict.fromkeys(
        h["name"] for h in f.station_hits if h["strength"] == "strong"))
    f.station = f.strong_stations[0] if f.strong_stations else None


_PLACE_LATIN_RE = re.compile(r"[A-Za-z]{2,}")
_PLACE_DIGIT_RE = re.compile(r"[0-9]")


def _place_like(v: str) -> bool:
    """像地名（可作起讫站候选）：不含数字、不含 2 个以上连续拉丁字母。"""
    s = (v or "").strip()
    if not (2 <= len(s) <= 8):
        return False
    if _PLACE_DIGIT_RE.search(s) or _PLACE_LATIN_RE.search(s):
        return False
    return bool(re.search(r"[\u4e00-\u9fa5]", s))


# 区间端点里混进来的"车种前缀"（"Z字头北京"→北京、"高铁上海"→上海）
_OD_PREFIX_RE = re.compile(
    r"^(?:[GDCTZKYSLNB]\s*(?:字头|字|头|车)|普速|高铁|动车|城际|绿皮车?)+")


# 区间端点里混进来的"疑问框架词"：从它开始的后半段不是站名。
# 实测：`app.od.parse_od("北京到上海需要中转吗")` → ("北京", "上海需要中转")
#       `app.od.parse_od("北京到上海有没有夕发朝至的卧铺")` → 匹配失败（t 超长）
_OD_FRAME_RE = re.compile(
    r"(有没有|会不会|能不能|可不可以|是否|还有|需要|中转|换乘|接续|联程|"
    r"几点|多少|多远|多久|多长时间|怎么|哪里|哪些|哪个|"
    r"最早|最晚|首班|末班|出发|到达|大屏|时刻|时刻表|余票|票价|价格|"
    r"吗|呢|吧|啊|的)")


def _truncate_at_frame(text: str) -> str:
    """在第一个疑问框架词处截断（用于区间解析的二次尝试）。"""
    m = _OD_FRAME_RE.search(text or "")
    if m and m.start() > 0:
        return text[:m.start()].strip()
    return text or ""


def _clean_od(od: tuple[str, str] | None) -> tuple[str, str] | None:
    """清洗区间端点：先剥车种前缀，再在疑问框架词处截断。

    实测到的两类脏数据：
      1. "Z字头北京到上海有哪些" → ("Z字头北京", "上海")
         "Z字头"是**车种偏好**，不是站名的一部分；
      2. "北京到上海需要中转吗" → ("北京", "上海需要中转")
         "需要中转"是问句框架，不是站名的一部分。
    截断只会**缩短**端点，不会把非站名"补"成站名，所以是安全操作。
    """
    if not od:
        return od
    out = []
    for v in od:
        s = _OD_PREFIX_RE.sub("", (v or "").strip()).strip()
        m = _OD_FRAME_RE.search(s)
        if m and m.start() > 0:          # 只截后半段，不整段丢
            s = s[:m.start()].strip()
        out.append(s or (v or "").strip())
    return (out[0], out[1])


def _validate_od(od: tuple[str, str] | None,
                 p: Provider) -> tuple[str, str] | None:
    """校验起讫站，挡掉"看起来是区间、其实不是"的假区间。

    实测到的一个真 bug：`app.od.parse_od("上海虹桥到达屏")` 返回
    `("上海虹桥", "达屏")` —— 把「到达屏」的"到"当成了区间分隔符。
    这种假区间会污染 `Slots.direction`，让下游按错误区间去查。

    规则（两端都要过）：
      1. 是站点索引里的真实站名 → 通过；
      2. 否则必须是"像地名"且 ≥3 字（小站可能不在兜底表里）；
      3. 2 字且不在站点表里 → 拒绝（"达屏""站台"正是被误切出来的）。
    """
    if not od:
        return None
    index = p.get_index()
    for v in od:
        s = (v or "").strip()
        if not s:
            return None
        if index and s in index:
            continue
        if len(s) >= 3 and _place_like(s):
            continue
        return None
    return od


# ==========================================================================
# 主抽取
# ==========================================================================
def extract(text: str, provider: Provider | None = None,
            skip_stations: bool = False) -> Facts:
    """把一句话解析成 Facts。纯函数，不联网、不改全局状态。"""
    p = provider or DEFAULT_PROVIDER
    raw = str(text or "")
    f = Facts(text=raw)
    f.norm = re.sub(r"\s+", "", raw).strip("？?。！!，,、；;：:")
    f.rstrip_len = len(f.norm)
    if not f.norm:
        return f

    # ---- 车次 ----
    try:
        code = p.train_code_parser(raw)
    except Exception:  # noqa: BLE001 —— 解析器异常不得影响判定
        code = default_train_code(raw)
    if code:
        f.train_codes = [code]
        f.train_code = code
        m = re.match(r"^0?([GDCTZKYSLBN])", code.upper())
        if m:
            f.train_prefix = m.group(1)
            f.train_class = TRAIN_PREFIXES.get(f.train_prefix)
        else:
            f.train_prefix = "#"
            from .knowledge import DIGIT_TRAIN
            f.train_class = DIGIT_TRAIN

    # ---- 车型 ----
    try:
        model = p.emu_model_parser(raw)
    except Exception:  # noqa: BLE001
        model = default_emu_model(raw)
    if model:
        f.emu_models = [model]
        f.emu_model = model
        for brand, members in EMU_BRANDS.items():
            if model in members:
                f.emu_brand = brand
                break
    for trait, meta in EMU_TRAIT_WORDS.items():
        if trait in raw:
            f.emu_traits.append(meta["zh"])

    # ---- 站点（trie 最长匹配 + 强弱分级）----
    if not skip_stations:
        match_stations(f, p.get_trie())
        f.station_source = p.station_source()

    # ---- 区间 ----
    try:
        f.od = p.od_parser(raw) or p.od_parser(f.norm)
    except Exception:  # noqa: BLE001
        f.od = default_od(raw) or default_od(f.norm)
    f.od = _validate_od(_clean_od(f.od), p)
    if f.od is None:
        # 二次尝试：区间解析失败常常是因为问句框架词让端点超长。
        # 例："北京到上海有没有夕发朝至的卧铺" 里 t 超过 10 字上限，直接匹配失败；
        # 截到第一个框架词之前再解析就得到 北京→上海。截断只缩短，不放宽。
        cut = _truncate_at_frame(f.norm)
        if cut and cut != f.norm:
            try:
                f.od = _validate_od(_clean_od(p.od_parser(cut)), p)
            except Exception:  # noqa: BLE001
                f.od = None

    # 区间里的两个站也算站名命中（"北京到上海"→北京/上海）
    if f.od:
        for st in f.od:
            if st and st not in f.strong_stations:
                f.strong_stations.append(st)
                if st not in f.stations:
                    f.stations.append(st)
        if not f.station:
            f.station = f.od[0]
    # 站名歧义：多个不同强站名，且没有区间来消解
    if len(f.strong_stations) > 1 and not f.od:
        f.station_ambiguous = True

    # ---- 线路 ----
    try:
        f.line = p.line_resolver(raw)
    except Exception:  # noqa: BLE001
        f.line = default_line_resolver(raw)

    # ---- 时间 ----
    for w in DATE_WORDS:
        if w in raw:
            f.date_word = w
            break
    for w in WEEKDAY_WORDS:
        if w in raw:
            f.weekday_word = w
            break
    for canon, words in TIME_WINDOW_WORDS.items():
        if any(w in raw for w in words):
            f.window_word = TIME_WINDOW_TAG[canon]
            break
    m = PATTERNS["clock"].search(raw)
    if m:
        hh = m.group(1)
        mm = m.group(2) or "00"
        f.clock = f"{int(hh):02d}:{int(mm):02d}"
    m = PATTERNS["date_iso"].search(raw)
    if m:
        f.date_iso = f"{int(m.group(1)):04d}-{int(m.group(2)):02d}-{int(m.group(3)):02d}"
    m = PATTERNS["month_day"].search(raw)
    if m:
        f.month_day = f"{int(m.group(1)):02d}-{int(m.group(2)):02d}"
    # 时间表述（retrieve/generate 会再规范化）
    parts = [x for x in (f.date_word, f.weekday_word, f.window_word) if x]
    if f.date_iso:
        parts.insert(0, f.date_iso)
    elif f.month_day:
        parts.insert(0, f.month_day)
    if parts:
        f.time_phrase = "".join(dict.fromkeys(parts)) if len(parts) > 1 else parts[0]
    elif f.clock:
        f.time_phrase = "今天"
        f.window_word = None

    # ---- 席别 / 车种 / 大屏方向 ----
    for canon, words in SEAT_WORDS.items():
        if any(w in raw for w in words):
            f.seat = SEAT_TAG[canon]
            break
    for canon, words in TRAIN_TYPE_PREF_WORDS.items():
        if any(w in raw for w in words):
            f.train_type_pref = TRAIN_TYPE_PREF_TAG[canon]
            break
    # 用户直接说车次前缀（"Z字头"/"K车"/"T打头"）→ 归为普速偏好。
    # ⚠️ 必须要求字母后面真的跟"字/头/车"：否则 "CR400BF" 里的 B、
    #    "G1" 里的 G 之后的字符都会误命中——实测 "CR400BF今天跑哪些车次"
    #    被标成了"普速"。
    if not f.train_type_pref and re.search(
            r"(?:^|[^A-Za-z0-9])[ZTKYSLNB](?:\s*(?:字头|头|字|车))", raw):
        f.train_type_pref = "普速"
    dep = bool(re.search(r"(出发|始发|发车|送站|开车|出发屏|发车屏)", raw))
    arr = bool(re.search(r"(到达|到站|接站|终到|到达屏)", raw))
    if dep and not arr:
        f.screen_direction = "departure"
    elif arr and not dep:
        f.screen_direction = "arrival"

    # ---- 问法标记 ----
    # 注意：这里**不含**「全程/历时/多长时间」——那些是问时间，不是问站序。
    # 实测"陇海线全程多少公里"会因为"全程"被标成"需要经停站序"，误导下游。
    f.wants_stops = bool(re.search(
        r"(经停|停靠|经过哪些站|经过的站|途经|站序|沿线|经过哪里|"
        r"多少个站|几站|有哪些站)", raw))
    f.wants_mileage = bool(re.search(
        r"(多少公里|多少千米|几公里|里程|距离|多远|全长)", raw))
    f.wants_night = bool(re.search(
        r"(夕发朝至|夜车|夜间车|卧铺过夜|晚上出发早上到|红眼)", raw))
    f.wants_first_last = bool(re.search(
        r"(首班|末班|最早一班|最晚一班|最早|最晚)", raw))
    f.wants_transfer = bool(re.search(r"(中转|换乘|接续|联程)", raw))
    return f


def flags_of(text: str) -> set[str]:
    """整句命中的语义标记（供树条件 `["flag", ...]` 使用）。"""
    out: set[str] = set()
    for w in KNOWLEDGE_HINTS:
        if w in text:
            out.add("knowledge")
            break
    for w in OUT_OF_SCOPE_HINTS:
        if w in text:
            out.add("out_of_scope")
            break
    for w in FRESHNESS_HINTS:
        if w in text:
            out.add("freshness")
            break
    for key in ("why", "how_many"):
        pass
    if re.search(r"(为什么|为何|什么原理|什么区别|有什么不同)", text):
        out.add("why")
    if re.search(r"(区别|不同|差别|对比|哪个好)", text):
        out.add("compare")
    if PATTERNS["code_like"].search(text):
        out.add("code_like")
    if PATTERNS["html_or_url"].search(text):
        out.add("url_like")
    if PATTERNS["pure_punct"].match(text):
        out.add("pure_punct")
    if PATTERNS["pure_digit"].match(text):
        out.add("pure_digit")
    if not PATTERNS["has_cjk"].search(text):
        out.add("no_cjk")
    if re.search(r"(临时|临客|加开|变点|停运|恢复开行|调图)", text):
        out.add("schedule_change")
    if re.search(r"(中转|换乘|联程|接续)", text):
        out.add("transfer")
    if re.search(r"(拍照|拍摄|机位|蹲守|取景|拍车|打卡|看车)", text):
        out.add("photo")
    return out


__all__ = [
    "PATTERNS", "Facts", "Provider", "DEFAULT_PROVIDER", "extract", "flags_of",
    "match_stations", "app_od_parser",
    "build_station_trie", "trie_scan", "hit_strength",
    "default_train_code", "default_emu_model", "default_od", "default_line_resolver",
]
