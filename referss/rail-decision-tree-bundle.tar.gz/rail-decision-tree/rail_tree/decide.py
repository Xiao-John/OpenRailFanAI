# -*- coding: utf-8 -*-
"""决策层：把树走成结论。

对外只暴露两件事：
    RailTree(provider).decide(message, history) -> Decision
    Decision.action == "plan"   → 确定接管（0 次 LLM 调用）
    Decision.action == "defer"  → 交回 AI，并带上**结构化原因**

为什么要带"原因"
----------------
原实现里 `plan()` 只返回 None，调用方看不出"为什么没接管"：
是没听懂？还是听懂了但缺槽位？还是问题性质需要模型判断？
这三种的优化方向完全不同（补词表 / 补槽位 / 保持不动）。
所以这里把原因做成枚举 + 细节，透出到日志，便于按原因统计覆盖率。
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field

from .build import REASON_ZH, build_tree
from .knowledge import FAMILIES
from .nodes import WalkContext, walk, stats as node_stats
from .text import DEFAULT_PROVIDER, Facts, Provider, extract, flags_of

_FAMILY_BY_KEY = {f["key"]: f for f in FAMILIES}

# 继承槽位时只认这些字段（与旧快路径 `ctx_text` 的继承范围一致）
_INHERIT_FIELDS = ("train_code", "od", "station", "line", "time_phrase",
                   "emu_model")


@dataclass
class Decision:
    action: str                      # "plan" | "defer"
    intent: str = ""
    qtype: str = "realtime"
    slots: dict = field(default_factory=dict)
    reason: str = ""                 # 机器可读（枚举）
    detail: str = ""                 # 人类可读
    matched: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    trace: list[dict] = field(default_factory=list)
    steps: int = 0
    elapsed_ms: float = 0.0

    @property
    def ok(self) -> bool:
        return self.action == "plan"

    def explain(self) -> str:
        if self.action == "plan":
            head = (f"接管：intent={self.intent} qtype={self.qtype} "
                    f"slots={self.slots}")
        else:
            head = f"交回 AI：{self.reason}（{self.detail}）"
        lines = [head, f"依据={self.matched}", f"耗时={self.elapsed_ms:.2f}ms "
                 f"步数={self.steps}"]
        if self.notes:
            lines.append("备注=" + "；".join(self.notes))
        lines.append(f"判断轨迹（{len(self.trace)} 步）：")
        for i, st in enumerate(self.trace, 1):
            mark = "✔" if st.get("hit") else "✘"
            lines.append(f"  {i:>3}. {mark} {st.get('label')} [{st.get('test')}]")
        return "\n".join(lines)


# ==========================================================================
# 槽位配方求值
# ==========================================================================
def resolve_slots(recipe: dict, ctx: WalkContext) -> dict:
    f = ctx.facts
    out: dict = {}
    for name, spec in (recipe or {}).items():
        v = _resolve_one(spec, f)
        if v:
            out[name] = v
    return out


def _resolve_one(spec, f: Facts):
    if not isinstance(spec, (list, tuple)) or not spec:
        return None
    kind = spec[0]
    if kind == "fact":
        attr = spec[1]
        if attr == "station":
            # 没有直接站名时用区间出发站兜底（"去哪拍"这类）
            return f.station or (f.od[0] if f.od else None)
        return getattr(f, attr, None)
    if kind == "od":
        return f"{f.od[0]}→{f.od[1]}" if f.od else None
    if kind == "extra":
        return f.extra_text()
    return None


# ==========================================================================
# 事实摘要（作为 matched，便于日志定位）
# ==========================================================================
def fact_summary(f: Facts) -> list[str]:
    out: list[str] = []
    if f.train_code:
        cls = (f.train_class or {}).get("zh")
        out.append(f"车次={f.train_code}" + (f"({cls})" if cls else ""))
    if f.emu_model:
        out.append(f"车型={f.emu_model}")
    if f.od:
        out.append(f"区间={f.od[0]}→{f.od[1]}")
    elif f.station:
        out.append(f"站名={f.station}")
    if f.line:
        out.append(f"线路={f.line}")
    if f.time_phrase:
        out.append(f"时间={f.time_phrase}")
    if f.seat:
        out.append(f"席别={f.seat}")
    if f.train_type_pref:
        out.append(f"车种={f.train_type_pref}")
    if f.station_ambiguous:
        out.append("站名歧义")
    if f.station_source and f.station_source != "unknown":
        out.append(f"站点源={f.station_source}")
    return out


# ==========================================================================
# 主入口
# ==========================================================================
class RailTree:
    """编译一次的决策树。构造后 decide() 可反复调用（无状态、线程安全）。"""

    def __init__(self, provider: Provider | None = None) -> None:
        self.provider = provider or DEFAULT_PROVIDER
        self.root = build_tree(self.provider)
        self.stats = node_stats(self.root)

    # ------------------------------------------------------------------
    def decide(self, message: str, history: list[dict] | None = None,
               explain: bool = False) -> Decision:
        t0 = time.perf_counter()
        text = str(message or "")
        # 站点匹配交给树里的 scan 节点做（这样它出现在判断轨迹里，
        # 且 trie 的节点数如实计入树规模）
        facts = extract(text, self.provider, skip_stations=True)
        notes: list[str] = []
        inherited = self._inherit(text, history, facts, notes)

        ctx = WalkContext(text=text, facts=facts, flags=flags_of(text),
                          provider=self.provider)
        result = walk(self.root, ctx)
        terminal = result.terminal

        matched = list(fact_summary(facts))
        if inherited:
            matched.append("继承上轮=" + ",".join(inherited))

        if terminal.get("t") == "plan":
            slots = resolve_slots(terminal.get("slots") or {}, ctx)
            note = terminal.get("note")
            # 注记只在"该家族产出 extra"时才并入——否则会给
            # 本来没有 extra 的家族凭空加一个槽位，破坏既有断言。
            if note and terminal.get("emit_extra", True):
                slots["extra"] = (slots.get("extra") + "；" + note) if slots.get(
                    "extra") else note
            matched = list(terminal.get("matched") or []) + matched
            return Decision(
                action="plan", intent=terminal["intent"],
                qtype=terminal.get("qtype", "realtime"), slots=slots,
                reason=terminal.get("reason", ""), matched=matched,
                notes=notes + ctx.notes,
                trace=result.trace if explain else [],
                steps=result.steps,
                elapsed_ms=(time.perf_counter() - t0) * 1000,
            )

        # ---- 降级 ----
        if terminal.get("t") == "defer_best":
            hint = ctx.defer_hint
            if hint:
                fam = _FAMILY_BY_KEY.get(hint.get("family") or "", {})
                reason = hint["reason"]
                detail = (f"已识别为「{fam.get('key', '')}」问法（意向 intent="
                          f"{hint.get('intent')}），但缺少关键槽位："
                          f"{'、'.join(hint.get('missing') or [])}")
            else:
                reason, detail = "UNKNOWN_FAMILY", REASON_ZH["UNKNOWN_FAMILY"]
        else:
            reason = terminal.get("reason", "UNKNOWN_FAMILY")
            detail = terminal.get("detail") or REASON_ZH.get(reason, "")

        return Decision(
            action="defer", reason=reason,
            detail=detail or REASON_ZH.get(reason, ""),
            matched=matched, notes=notes + ctx.notes,
            trace=result.trace if explain else [],
            steps=result.steps,
            elapsed_ms=(time.perf_counter() - t0) * 1000,
        )

    # ------------------------------------------------------------------
    def _inherit(self, text: str, history: list[dict] | None, facts: Facts,
                 notes: list[str]) -> list[str]:
        """多轮继承：本次没给车次/站名/区间时，从最近用户消息里补。

        与旧快路径的行为一致（"那明天呢"这类追问要靠它）。
        只填**缺失**的字段，绝不覆盖本次输入解析出的结果。
        """
        if not history:
            return []
        prev_text = " ".join(
            str(m.get("content") or "") for m in history
            if str(m.get("role")) == "user")
        if not prev_text.strip():
            return []
        # ⚠️ 这里**不能** skip_stations：历史消息里的站名也要匹配出来，
        # 否则"北京南站" → "大屏呢" 这类追问继承不到站点，白白降级。
        prev = extract(prev_text[-200:], self.provider, skip_stations=False)
        inherited: list[str] = []
        for fld in _INHERIT_FIELDS:
            if getattr(facts, fld, None):
                continue
            val = getattr(prev, fld, None)
            if not val:
                continue
            setattr(facts, fld, val)
            inherited.append(f"{fld}={val}")
        if inherited:
            if facts.train_code and not facts.train_codes:
                facts.train_codes = [facts.train_code]
            if facts.station and not facts.strong_stations:
                facts.strong_stations = [facts.station]
            notes.append("多轮继承：" + "、".join(inherited))
        return inherited


_default_tree: RailTree | None = None


def get_default_tree() -> RailTree:
    """进程内单例（建树要编译站点 trie，别每次问答都重建）。"""
    global _default_tree
    if _default_tree is None:
        _default_tree = RailTree()
    return _default_tree


def decide(message: str, history: list[dict] | None = None,
           explain: bool = False) -> Decision:
    return get_default_tree().decide(message, history=history, explain=explain)


__all__ = ["Decision", "RailTree", "decide", "get_default_tree",
           "resolve_slots", "fact_summary"]
