# -*- coding: utf-8 -*-
"""决策树的节点类型、求值器与统计（零依赖）。

树的表示是一棵**纯数据**的嵌套 dict（JSON 可序列化），
这样它既能被程序生成，也能被人检视、被 dump 出来做回归对照。

节点类型
--------
    {"t":"cond",  "id", "label", "test", "yes", "no"}   二分判断
    {"t":"scan",  "id", "label", "op", "args", "next"}  抽事实（副作用），恒走 next
    {"t":"trie",  "id", "ch", "end"}                    站点 trie 节点
    {"t":"plan",  "intent", "qtype", "slots", ...}      终态：确定性接管
    {"t":"defer", "reason", "detail"}                   终态：交回 AI

为什么把定位也做成节点
----------------------
`scan` 节点让"抽站点/时间/席别"成为树的一部分而不是树外面的预处理：
它出现在判断轨迹里（可解释），并且条件数统计能如实反映树的规模。
站点 trie 的每个节点（"下一个字是不是 X"）同样是货真价实的判断条件。

踩过的坑（沿用上一个项目的教训）
--------------------------------
每个 cond 节点都有唯一 id。`stats()` 会校验**没有 id 被走到两次**——
否则说明子树被两处引用（DAG），条件数与落盘体积都会虚高、
判断轨迹也不再可解释。宁可构建时直接报错。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from .text import PATTERNS, Facts, Provider

# ==========================================================================
# 终态构造
# ==========================================================================
def make_plan(intent: str, qtype: str, slots: dict | None = None,
              reason: str = "", matched: list[str] | None = None,
              note: str = "", emit_extra: bool = True) -> dict:
    return {"t": "plan", "intent": intent, "qtype": qtype,
            "slots": dict(slots or {}), "reason": reason,
            "matched": list(matched or []), "note": note,
            "emit_extra": emit_extra}


def make_defer(reason: str, detail: str = "") -> dict:
    return {"t": "defer", "reason": reason, "detail": detail}


def make_defer_best() -> dict:
    """兜底终态：优先使用沿途记录下来的"最具体的降级原因"。

    为什么需要它：家族命中但缺槽位时（例如"乐清到杭州还有票吗"里
    「乐清」不在站点表），我们应当告诉用户/日志"是哪个家族、缺哪个槽位"，
    而不是笼统的"没看懂"。纯叶子无法回读运行时状态，所以用这个终态
    让 decide() 去读 ctx 上的 defer_hint。
    """
    return {"t": "defer_best"}


class TreeBuilder:
    """建树助手：分配 id、统计、防止 id 复用。"""

    def __init__(self) -> None:
        self._next = 0
        self.counters: dict[str, int] = {}

    def new_id(self) -> int:
        self._next += 1
        return self._next

    def cond(self, label: str, test: list, yes: dict, no: dict) -> dict:
        self.counters["cond"] = self.counters.get("cond", 0) + 1
        return {"t": "cond", "id": self.new_id(), "label": label,
                "test": test, "yes": yes, "no": no}

    def scan(self, label: str, op: str, next_node: dict,
             args: dict | None = None) -> dict:
        self.counters["scan"] = self.counters.get("scan", 0) + 1
        return {"t": "scan", "id": self.new_id(), "label": label, "op": op,
                "args": dict(args or {}), "next": next_node}


# ==========================================================================
# 判断上下文
# ==========================================================================
@dataclass
class WalkContext:
    text: str
    facts: Facts
    flags: set[str] = field(default_factory=set)
    provider: Provider | None = None
    slots: dict = field(default_factory=dict)
    family: dict | None = None
    family_hits: list[dict] = field(default_factory=list)
    matched: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    defer_hint: dict | None = None
    history_text: str = ""

    def note(self, s: str) -> None:
        if s and s not in self.notes:
            self.notes.append(s)

    def mark(self, s: str) -> None:
        if s and s not in self.matched:
            self.matched.append(s)


# ==========================================================================
# 测试 DSL
# ==========================================================================
def _get_hits(facts: Facts, field_name: str) -> int:
    v = getattr(facts, field_name, None)
    if v is None:
        return 0
    try:
        return len(v)
    except TypeError:
        return 1 if v else 0


def eval_test(test: Any, ctx: WalkContext) -> bool:
    """求值一个测试。测试写成 list（JSON 友好），第一个元素是种类。"""
    if not isinstance(test, (list, tuple)) or not test:
        return False
    kind = test[0]
    f = ctx.facts

    if kind == "true":
        return True
    if kind == "flag":
        return test[1] in ctx.flags
    if kind == "noflag":
        return test[1] not in ctx.flags
    if kind == "slot":
        return bool(ctx.slots.get(test[1]))
    if kind == "nslot":
        return not ctx.slots.get(test[1])
    if kind == "hits":
        left = _get_hits(f, test[1])
        op, right = test[2], test[3]
        return {"==": left == right, ">=": left >= right, "<=": left <= right,
                ">": left > right, "<": left < right}.get(op, False)
    if kind == "attr":
        return bool(getattr(f, test[1], None))
    if kind == "attr_eq":
        return getattr(f, test[1], None) == test[2]
    if kind == "attr_in":
        return getattr(f, test[1], None) in tuple(test[2])
    if kind == "re":
        pat = PATTERNS.get(test[1])
        return bool(pat and pat.search(ctx.text))
    if kind == "all":
        return all(eval_test(t, ctx) for t in test[1])
    if kind == "any":
        return any(eval_test(t, ctx) for t in test[1])
    if kind == "not":
        return not eval_test(test[1], ctx)
    if kind == "emu_only":
        return bool(f.train_class and f.train_class.get("emu"))
    if kind == "train_known":
        return bool(f.train_code)
    if kind == "family_is":
        return bool(ctx.family and ctx.family.get("key") == test[1])
    if kind == "needs":
        return bool(ctx.family and test[1] in ctx.family.get("slots", []))
    if kind == "family_hit":
        return any(fam.get("key") == test[1] for fam in ctx.family_hits)
    if kind == "re_any":
        return any(w in ctx.text for w in test[1])
    if kind == "has_od":
        return bool(f.od)
    if kind == "no_od":
        return not f.od
    if kind == "has_train":
        return bool(f.train_code)
    if kind == "no_train":
        return not f.train_code
    if kind == "has_station":
        return bool(f.station)
    if kind == "has_line":
        return bool(f.line)
    if kind == "has_emu":
        return bool(f.emu_model)
    if kind == "len":
        left = len(ctx.text or "")
        op, right = test[1], test[2]
        return {"==": left == right, ">=": left >= right, "<=": left <= right,
                ">": left > right, "<": left < right}.get(op, False)
    if kind == "n_families":
        n = len(ctx.family_hits)
        op, right = test[1], test[2]
        return {"==": n == right, ">=": n >= right, "<=": n <= right}.get(op, False)
    if kind == "ambiguous_station":
        return bool(f.station_ambiguous)
    if kind == "station_ok":
        need_od = test[1] if len(test) > 1 else False
        if need_od:
            return bool(f.od)
        return bool(f.station) and not f.station_ambiguous
    return False


def describe_test(test: Any) -> str:
    """把测试渲染成人类可读的短句（进判断轨迹）。"""
    if not isinstance(test, (list, tuple)) or not test:
        return str(test)
    kind = test[0]
    return {
        "flag": lambda: f"标记[{test[1]}]",
        "noflag": lambda: f"无标记[{test[1]}]",
        "slot": lambda: f"槽位[{test[1]}]非空",
        "nslot": lambda: f"槽位[{test[1]}]为空",
        "hits": lambda: f"{test[1]} {test[2]} {test[3]}",
        "attr": lambda: f"有[{test[1]}]",
        "attr_eq": lambda: f"{test[1]}=={test[2]}",
        "re": lambda: f"正则[{test[1]}]",
        "emu_only": lambda: "车次是动车组(G/D/C)",
        "train_known": lambda: "识别出车次",
        "family_is": lambda: f"家族={test[1]}",
        "needs": lambda: f"该家族需要槽位[{test[1]}]",
        "n_families": lambda: f"命中家族数 {test[1]} {test[2]}",
        "ambiguous_station": lambda: "站名有歧义",
        "station_ok": lambda: "站名可用" + ("(需区间)" if len(test) > 1 and test[1] else ""),
        "all": lambda: "且(" + " & ".join(describe_test(t) for t in test[1]) + ")",
        "any": lambda: "或(" + " | ".join(describe_test(t) for t in test[1]) + ")",
        "not": lambda: "非(" + describe_test(test[1]) + ")",
        "family_hit": lambda: f"命中家族[{test[1]}]",
        "len": lambda: f"输入长度 {test[1]} {test[2]}",
        "re_any": lambda: "含[" + "/".join(test[1][:4]) + "]",
        "has_od": lambda: "有区间",
        "no_od": lambda: "无区间",
        "has_train": lambda: "有车次",
        "no_train": lambda: "无车次",
        "has_station": lambda: "有站名",
        "has_line": lambda: "有线路名",
        "has_emu": lambda: "有车型",
        "true": lambda: "恒真",
    }.get(kind, lambda: str(test))()


# ==========================================================================
# scan 操作（副作用：往 ctx 里放事实）
# ==========================================================================
def _op_probe_families(ctx: WalkContext, families: list[dict]) -> None:
    """把命中的问法家族记到 ctx.family_hits / ctx.family（第一个命中的）。"""
    for fam in families:
        words = fam.get("any_words") or []
        if any(w in ctx.text for w in words):
            ctx.family_hits.append(fam)
    if ctx.family_hits and ctx.family is None:
        ctx.family = ctx.family_hits[0]
        ctx.mark(f"家族={ctx.family['key']}")


def _op_stations(ctx: WalkContext, trie: dict | None = None) -> None:
    """站点 trie 匹配（trie 由 build_tree 内嵌在节点参数里）。"""
    from .text import match_stations

    if trie:
        match_stations(ctx.facts, trie)


def _op_plan_hints(ctx: WalkContext, families: list | None = None) -> None:
    """走家族链之前，先算出"最高优先级的那个命中家族缺哪些槽位"。

    为什么放在这里：家族链为了保持"真正的树"，把"家族命中 + 槽位齐备"
    合并成了**单个条件**（否则同一个后续节点会被引用两次 → DAG）。
    合并后就没地方记录"到底缺了哪个槽位"了，于是用一个前置 scan 统一补齐。
    它只写 ctx.defer_hint，真正的终态仍由家族的 defer_best 决定。
    """
    from .knowledge import SLOT_TEST

    for fam in (families or ctx.family_hits or []):
        if fam.get("key") not in [f.get("key") for f in ctx.family_hits]:
            continue
        specs = fam.get("slots") or []
        if not specs:
            return                      # 该家族不缺槽位 → 不需要提示
        missing: list[str] = []
        for spec in specs:
            names = spec if isinstance(spec, list) else [spec]
            tests = [SLOT_TEST.get(n) for n in names if SLOT_TEST.get(n)]
            if tests and not any(eval_test(t, ctx) for t in tests):
                missing.append("/".join(names))
        if missing:
            ctx.defer_hint = {"reason": "NO_SLOT", "family": fam["key"],
                              "intent": fam.get("intent", ""),
                              "missing": missing}
            ctx.note(f"家族[{fam['key']}]缺槽位[{','.join(missing)}]")
            return
        return                          # 槽位齐备 → 会走 plan，无需提示


OPS = {
    "probe_families": _op_probe_families,
    "stations": _op_stations,
    "plan_hints": _op_plan_hints,
}


# ==========================================================================
# 走树
# ==========================================================================
@dataclass
class WalkResult:
    terminal: dict
    trace: list[dict]
    steps: int


def walk(root: dict, ctx: WalkContext, max_steps: int = 4000) -> WalkResult:
    """沿树下行直到终态；返回终态、判断轨迹与步数。"""
    node = root
    trace: list[dict] = []
    steps = 0
    while True:
        steps += 1
        if steps > max_steps:
            return WalkResult(make_defer("TREE_TOO_DEEP", "判断步数超限"),
                              trace, steps)
        t = node.get("t")
        if t == "cond":
            hit = eval_test(node["test"], ctx)
            trace.append({"id": node["id"], "label": node["label"],
                          "test": describe_test(node["test"]), "hit": hit})
            node = node["yes"] if hit else node["no"]
        elif t == "scan":
            op = OPS.get(node["op"])
            if op:
                op(ctx, **(node.get("args") or {}))
            trace.append({"id": node["id"], "label": node["label"],
                          "test": f"抽取:{node['op']}", "hit": True})
            node = node["next"]
        else:
            return WalkResult(node, trace, steps)


# ==========================================================================
# 统计（含 DAG 校验与 trie 计数）
# ==========================================================================
def stats(root: dict) -> dict:
    """统计节点规模。cond 的 id 必须唯一，否则说明树是 DAG。"""
    nodes = conds = scans = plans = defers = trie_nodes = 0
    depth = 0
    seen_ids: set[int] = set()
    stack: list[tuple[dict, int]] = [(root, 1)]
    while stack:
        n, d = stack.pop()
        depth = max(depth, d)
        t = n.get("t")
        if t == "cond":
            nid = n.get("id")
            if nid in seen_ids:
                raise RuntimeError(
                    f"rail_tree 不是树：cond id={nid} 被引用两次（共享子树/DAG）。")
            seen_ids.add(nid)
            conds += 1
            nodes += 1
            stack.append((n["yes"], d + 1))
            stack.append((n["no"], d + 1))
        elif t == "scan":
            scans += 1
            nodes += 1
            # 站点 trie 内嵌在 scan 的参数里，它的节点同样是判断条件
            # （"下一个字是不是 X"），必须计入规模。
            trie_root = (n.get("args") or {}).get("trie")
            if trie_root:
                stack.append((trie_root, d + 1))
            stack.append((n["next"], d + 1))
        elif t is None and "ch" in n:
            # 站点 trie 节点：没有 "t" 字段，靠 "ch" 识别。
            # 每个节点 = 一个"下一个字是否为 X"的判断条件，必须计入规模。
            trie_nodes += 1
            nodes += 1
            for child in (n.get("ch") or {}).values():
                stack.append((child, d + 1))
        elif t == "plan":
            plans += 1
            nodes += 1
        else:                       # "defer" / "defer_best"
            defers += 1
            nodes += 1
    return {
        "nodes": nodes,
        "conditions": conds,                 # 二分判断条件
        "trie_conditions": trie_nodes,       # 站点 trie 的判断条件
        "scan_nodes": scans,                 # 事实抽取节点（也在轨迹里）
        "plans": plans,
        "defers": defers,
        "depth": depth,
        "total_conditions": conds + trie_nodes + scans,
        "unique_cond_ids": len(seen_ids),
    }


__all__ = [
    "TreeBuilder", "WalkContext", "WalkResult", "eval_test", "describe_test",
    "walk", "stats", "make_plan", "make_defer", "make_defer_best", "OPS",
]
